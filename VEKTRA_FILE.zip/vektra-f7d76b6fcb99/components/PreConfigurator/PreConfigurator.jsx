import React from 'react'
import HeroSection from '@components/PreConfigurator/Herosection/Hero'
import Filters from './Filter/Filter'
import Products from '@components/Homepage/TrandingPcs/Trading'
const PreConfig = () => {
  return (
    <React.Fragment>
      <HeroSection />
      <Filters />
      {/* <Products /> */}
    </React.Fragment>
  )
}
export default PreConfig
