import cn from 'classnames'
import type { SearchPropsType } from '@lib/search-props'
import Link from 'next/link'
import { useState,useRef,useEffect } from 'react'
import { useRouter } from 'next/router'
import { Spacing } from "@components/GlobalComponents/Spacing"
import { Layout } from '@components/common'
import { ProductCard } from '@components/product'
import type { Product } from '@commerce/types/product'
import {  Grid, Skeleton } from '@components/ui'
import { Container } from './GlobalComponents/Container'
import HeroSection from "./GlobalComponents/Herosection/Hero"
import { Wrapper } from "./Search.Style"
import useSearch from '@framework/product/use-search'
import Breadcrumbs from '@components/breadcrumbs/Breadcrumbs'
import getSlug from '@lib/get-slug'
import rangeMap from '@lib/range-map'
import { HiddenXS } from './GlobalComponents/Desktop-visible'
import {FiFilter} from "react-icons/fi"
import { MdClose } from "react-icons/md"
import Head from 'next/head';
import useOutsideAlerter from "./handleOutsideHandler"
import Button from "@components/ui/Button"
const SORT = Object.entries({
  'trending-desc': 'Trending',
  'latest-desc': 'Latest arrivals',
  'price-asc': 'Price: Low to high',
  'price-desc': 'Price: High to low',
})

import {
  filterQuery,
  getCategoryPath,
  getDesignerPath,
  useSearchMeta,
} from '@lib/search'
import { Row } from './GlobalComponents/row'
import { Col_12, Col_3, Col_9 } from './GlobalComponents/Column'
import { Heading1 } from './GlobalComponents/Heading'
import { VisibleXS } from './GlobalComponents/Mobile-visible'

export default function Search({ categories, brands, pages, seo }: SearchPropsType) {
  // console.log("pagespages0", categories)
  const [activeFilter, setActiveFilter] = useState('');
  const [toggleFilter, setToggleFilter] = useState(false);
  const [start, setStart] = useState(12);
  const [last, setLast] = useState();
  const [after, setAfter] = useState();
  const [before, setBefore] = useState();
  
  const ref = useRef();
  const router = useRouter()
  const { asPath, locale } = router
  const { q, sort } = router.query;
  const wrapperRef = useRef(null);
  const setDefault = () => {
    setActiveFilter(""); 
  }
  useOutsideAlerter(wrapperRef, setDefault);
  const sortArr = ['Trending','Latest arrivals','Price: Low to high','Price: High to low'];
  
  let sortKey = 0;
  if(sort=='trending-desc'){
    sortKey = 0;
  }
  else if(sort=='latest-desc'){
    sortKey = 1;
  }
  else if(sort =='price-asc'){
    sortKey = 2;
  }
  else if(sort == 'price-desc'){
    sortKey = 3;
  }
  // `q` can be included but because categories and designers can't be searched
  // in the same way of products, it's better to ignore the search input if one
  // of those is selected
  const query = filterQuery({ sort })
  // console.log("asPath", categories)
  const { pathname, category, brand } = useSearchMeta(asPath)
  const activeCategory = categories.find((cat: any) => cat.slug === category)
  // console.log("asPath", activeCategory)
  const activeBrand = brands.find(
    (b: any) => getSlug(b.node.path) === `brands/${brand}`
  )?.node

  var checkflag = true;
  if(category && brand == undefined) {
    checkflag = false;
  }
  // if(q) {
  //   checkflag = true;
  // }
  // else if(brand == undefined){
  //   checkflag = false;
  // }
  
  const { data } = useSearch({
    search: typeof q === 'string' ? q : '',
    categoryId: activeCategory?.id,
    brandId: (activeBrand as any)?.entityId,
    sort: typeof sort === 'string' ? sort : '',
    locale,
    first: (checkflag)? 250 :start,
    last: last,
    before: before,
    after: after,
  })
  
  const showPagination = (checkflag)?false:true;
  const handleClick = (event: any, filter: string)  => {
    if (filter !== activeFilter) {     
      setToggleFilter(true)
     
    } else {   
      setToggleFilter(!toggleFilter)     
    }
    setActiveFilter(filter); 
    // document.addEventListener("mousedown", myFunction);
    // function myFunction() {
    //   console.log("Ddd");
    //   handleClick(event, "")
    // }
  }
 
  

const [click,setClick] = useState(false);
const filter = () => {
  setClick(!click);
  document.body.style.overflow = 'hidden';
}
const filterclose = () => {
  setClick(!click);
  document.body.style.overflow = '';
}
function capitalize(input:any = "") {  
  const mySentence = input.replace(/[^a-zA-Z0-9]/g, " ");
  const words = mySentence.split(" ");

  for (let i = 0; i < words.length; i++) {
      if(isNaN(words[i])) {
          words[i] = words[i][0].toUpperCase() + words[i].substr(1);
      } else {
          words[i] = words[i][0]
      }
  }
  return words.join(' ');  
} 

// Brands dropdown render from here
// If you want to all brand in dropdown just replace newBrands to brands

let prevCursor = data?.collection?.products?.edges[0]?.cursor;
let nextCursor = data?.collection?.products?.edges[data?.collection?.products?.edges.length-1]?.cursor;
let hasPreviousPage = (data?.collection?.products?.pageInfo?.hasPreviousPage);
let hasNextPage = (data?.collection?.products?.pageInfo?.hasNextPage);
const showPagination2 = (hasNextPage || hasPreviousPage)?true:false;

let productVendorArr = new Array(); 
data?.collection?.products?.edges.map((v) => {
  productVendorArr.push(v?.node?.vendor);
})
let uniqueVendorArr = productVendorArr.filter(function(elem, index, self) {
  return index === self.indexOf(elem);
})
let newBrands = [...new Set(uniqueVendorArr)].map((v) => {
  const id = v.replace(/\s+/g, '-').toLowerCase()
  return {
    node: {
      entityId: id,
      name: v,
      path: `brands/${id}`,
    },
  }
})
// Brand dropdown functionality end
// console.log("data?.collection", data?.products);
  return (
    <>
    <Head>
      <title>{seo?.title}</title>
      <meta name="description" content={seo?.description} />
      <meta name="og:title" content={seo?.title} />
      <meta name="og:description" content={seo?.description} />
    </Head> 
    <Spacing >
          
    <Wrapper>
    <Breadcrumbs breadcrumbs={activeCategory?.name
                      ? `Collection: ${activeCategory?.name}`
                      : 'All Categories'} />
      <Container>
        <HiddenXS>
          <HeroSection banner={data?.collection?.image?.originalSrc} />
        </HiddenXS>
        <div className="titlbar">
          <Heading1 className="title">{activeCategory?.name
                        ? `${activeCategory?.name}`
                        : 'All Collection'}
          </Heading1>
          <VisibleXS>
            <span className="filter" onClick={filter}>
              <FiFilter className="icons"/>
            </span>
           
          </VisibleXS>
        </div>
        <Row >  
          <Col_12>
            <div 
              ref={wrapperRef}
            className={ click ? "filer_blog open" : "filer_blog"}>
              <VisibleXS>
            <div className="titlbar2">
                <Heading1>Filters</Heading1>
               
                  <span  onClick={filterclose}>
                    <MdClose className="icons"/>
                  </span>
                
              </div>
              </VisibleXS>
          

          
            {/* Categories */}
            <div className="relative inline-block ">
              <div 
            
              className="lg:block">
                <span className="rounded-md shadow-sm">
                  <button
                    type="button"
                    onClick={(e) => handleClick(e, 'categories')}
                    className="flex filterbt justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-4 hover:text-accent-5 focus:outline-none focus:border-blue-300 focus:shadow-outline-normal active:bg-accent-1 active:text-accent-8 transition ease-in-out duration-150"
                    id="options-menu"
                    aria-haspopup="true"
                    aria-expanded="true"
                  >
                    {activeCategory?.name
                      ? `Collection: ${activeCategory?.name}`
                      : 'All Categories'}
                    <svg
                      className="-mr-1 ml-2 h-5 w-5"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>
                </span>
              </div>
              <div
                className={`origin-top-left absolute lg:relative left-0 w-full rounded-md shadow-lg lg:shadow-none z-10    ${
                  activeFilter !== 'categories' || toggleFilter !== true
                    ? 'hidden'
                    : ''
                }`}
              >
                <div className="rounded-sm  shadow-xs lg:bg-none lg:shadow-none">
                  <div
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="options-menu"
                  >
                    <ul 
                    
                    className='lsitngfilter'>
                      {/* <li
                        className={cn(
                          'block text-sm leading-5 text-accent-4 lg:text-base lg:no-underline lg:font-bold lg:tracking-wide hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                          {
                            underline: !activeCategory?.name,
                          }
                        )}
                      >
                        <Link
                          href={{ pathname: getCategoryPath('', brand), query }}
                        >
                          <a
                            onClick={(e) => handleClick(e, 'categories')}
                            className={
                              'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                            }
                          >
                            All Categories
                          </a>
                        </Link>
                      </li> */}
                      {categories.map((cat: any) => (
                        <li
                          key={cat.path}
                          className={cn(
                            'block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                            {
                              underline: activeCategory?.id === cat.id,
                            }
                          )}
                        >
                          {/* <Link
                            href={{
                              pathname: getCategoryPath(cat.path, brand),
                              query,
                            }}
                          > */}
                            <a
                              href={ getCategoryPath(cat.path, brand) }
                              onClick={(e) => handleClick(e, 'categories')}
                              className={
                                'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                              }
                            >
                              {cat.name}
                            </a>
                          {/* </Link> */}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Designs */}
            <div className="relative inline-block ">
              <div className="lg:block">
                <span className="rounded-md shadow-sm">
                  <button
                    type="button"
                    onClick={(e) => handleClick(e, 'brands')}
                    className="flex filterbt justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-8 hover:text-accent-5 focus:outline-none focus:border-blue-300 focus:shadow-outline-normal active:bg-accent-1 active:text-accent-8 transition ease-in-out duration-150"
                    id="options-menu"
                    aria-haspopup="true"
                    aria-expanded="true"
                  >
                    {activeBrand?.name
                      ? `Brand: ${activeBrand?.name}`
                      : 'All Brands'}
                    <svg
                      className="-mr-1 ml-2 h-5 w-5"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>
                </span>
              </div>
              <div
                className={`origin-top-left absolute lg:relative left-0  w-full rounded-md shadow-lg lg:shadow-none z-10  ${
                  activeFilter !== 'brands' || toggleFilter !== true
                    ? 'hidden'
                    : ''
                }`}
              >
                <div className="rounded-sm  shadow-xs lg:bg-none lg:shadow-none">
                  <div
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="options-menu"
                  >
                    <ul 
                    
                    className='brandfilter'>
                      {/* <li
                        className={cn(
                          'block text-sm leading-5 text-accent-4 lg:text-base lg:no-underline lg:font-bold lg:tracking-wide hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                          {
                            underline: !activeBrand?.name,
                          }
                        )}
                      >
                        <Link
                          href={{
                            pathname: getDesignerPath('', category),
                            query,
                          }}
                        >
                          <a
                            onClick={(e) => handleClick(e, 'brands')}
                            className={
                              'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                            }
                          >
                            All Designers
                          </a>
                        </Link>
                      </li> */}
                      <li  className={cn(
                            'block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                      )}>
                        <Link href={`https://www.vektrapc.com/collections/${activeCategory?.slug}`}>
                          <a
                            onClick={(e) => handleClick(e, 'brands')}
                            className={
                              'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                            }
                          >
                            All Brands
                          </a>
                        </Link>
                      </li>
                      {newBrands.flatMap(({ node }: { node: any }) => (
                        <li
                          key={node.path}
                          className={cn(
                            'block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                            {
                              // @ts-ignore Shopify - Fix this types
                              underline: activeBrand?.entityId === node.entityId,
                            }
                          )}
                        >
                          {/* <Link
                            href={{
                              pathname: getDesignerPath(node.path, category),
                              query,
                            }}
                          > */}
                            <a
                              href={getDesignerPath(node.path, category)}
                              onClick={(e) => handleClick(e, 'brands')}
                              className={
                                'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                              }
                            >
                              {node.name}
                            </a>
                          {/* </Link> */}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
             
            <div className="right-sort">
              <div className="lg:block">
                <span className="rounded-md shadow-sm">
                  <button
                    type="button"
                    onClick={(e) => handleClick(e, 'sort')}
                    className="flex filterbt-srt justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-4 hover:text-accent-5 transition ease-in-out duration-150"
                    id="options-menu"
                    aria-haspopup="true"
                    aria-expanded="true"
                  >
                    {sort ? `Sort: ${sortArr[sortKey]}` : 'Sort By'}
                    <svg
                      className="-mr-1 ml-2 h-5 w-5"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>
                </span>
              </div>
              <div
                className={`origin-top-left absolute lg:relative left-0  w-full rounded-md shadow-lg lg:shadow-none z-10   ${
                  activeFilter !== 'sort' || toggleFilter !== true ? 'hidden' : ''
                }`}
              >
                <div className="rounded-sm  shadow-xs lg:bg-none lg:shadow-none">
                  <div
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="options-menu"
                  >
                    <ul 
                      ref={wrapperRef}
                    className='sortfilter'>
                      {/* <li
                        className={cn(
                          'block text-sm leading-5 text-accent-4 lg:text-base lg:no-underline lg:font-bold lg:tracking-wide hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                          {
                            underline: !sort,
                          }
                        )}
                      >
                        <Link href={{ pathname, query: filterQuery({ q }) }}>
                          <a
                            onClick={(e) => handleClick(e, 'sort')}
                            className={
                              'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                            }
                          >
                            Relevance
                          </a>
                        </Link>
                      </li> */}
                      {SORT.map(([key, text]) => (
                        <li
                          key={key}
                          className={cn(
                            'block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8',
                            {
                              underline: sort === key,
                            }
                          )}
                        >
                          <Link
                            href={{
                              pathname,
                              query: filterQuery({ q, sort: key }),
                            }}
                          >
                            <a
                              onClick={(e) => handleClick(e, 'sort')}
                              className={
                                'block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4'
                              }
                            >
                              {text}
                            </a>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
         
            
            </div>
            
          </Col_12>
          <Col_12>
                <div className="col-span-12 order-12 lg:order-none">
                  {(q || activeCategory || activeBrand) && (
                    <div className=" transition ease-in duration-75 sercblog hidden" style={{color:"#fff",marginBottom: '10px'}}>
                      {data ? (
                        <>
                          <span
                            className={cn('animated', {
                              fadeIn: data.found,
                              hidden: !data.found,
                            })}
                          >
                            Showing {data.products?.length} results{' '}
                            {q && (
                              <>
                                for "<strong>{q}</strong>"
                              </>
                            )}
                          </span>
                          <span
                            className={cn('animated', {
                              fadeIn: !data.found,
                              hidden: data.found,
                            })}
                          >
                            {q ? (
                              <>
                                There are no products that match "<strong>{q}</strong>"
                              </>
                            ) : (
                              <>
                                There are no products that match the selected category.
                              </>
                            )}
                          </span>
                        </>
                      ) : q ? (
                        <>
                          Searching for: "<strong>{q}</strong>"
                        </>
                      ) : (
                        <>Searching...</>
                      )}
                    </div>
                  )}
                  {data ? (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-4">
                      
                      {data.products.map((product: Product) => (
                        <ProductCard
                          variant="simple"
                          key={product.path}
                          className="animated fadeIn"
                          product={product}
                          imgProps={{
                            width: 480,
                            height: 480,
                          }}
                        />
                  
                      ))}
                      
                      {/* <button
                        type="button"
                        onClick={(e) => setStart(start+12)}
                        className="flex filterbt-srt justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-4 hover:text-accent-5 transition ease-in-out duration-150"
                        id="options-menu"
                        aria-haspopup="true"
                        aria-expanded="true"
                      >
                        Load More
                      </button> */}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                      {rangeMap(12, (i) => (
                        <Skeleton key={i}>
                          <div className="w-60 h-60" />
                        </Skeleton>
                      ))}
                    </div>
                  )}{' '}
                  { (showPagination && showPagination2) && (
                  <div className="paginationbtn"> 
                    <Button
                      type="button"
                      disabled={(hasPreviousPage)?false:true}
                      onClick={() => {
                        setLast(12 as any)
                        setBefore(prevCursor as any)
                        setStart(null as any)
                        setAfter(null as any)
                      }}
                    >
                      <span> &laquo; Previous  </span>
                    </Button>
                    <Button
                      type="submit"
                      disabled={(hasNextPage )?false:true}
                      onClick={() => {
                        setStart(12 as any)
                        setAfter(nextCursor as any)
                        setLast(null as any)
                        setBefore(null as any)
                      }}
                    >
                      <span> Next &raquo; </span>
                    </Button>
                  </div>
                  )}
                </div>
          </Col_12>
        </Row>
          
        
        
      </Container>
    </Wrapper>
    </Spacing>
    </>
  )
}

Search.Layout = Layout
