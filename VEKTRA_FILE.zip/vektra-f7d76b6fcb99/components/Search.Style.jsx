import styled from "styled-components"
export const Wrapper = styled.div`
.title{
    font-size: 40px;
    margin: 15px 0 25px;
}
.titlbar2 {
    background: #ffbf56;
    border-radius: 0;
    padding: 5px 15px;
    margin-bottom: 0;

     h1 {
        font-size: 19px;
        text-align: left;
        color: #0e0e0e;
        margin-bottom: 0;
        line-height: unset;
        text-transform: uppercase;
    }
}
.filer_blog {
    padding: 0;
    border: 0px solid #ffbf56;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
     
    .relative {
        margin-right: 0;
        width: auto;
        margin-bottom: 0px;
        margin-right: 15px;
    }
    .filterbt{
        ${'' /* min-width: 200px; */}
        background: transparent;
    color: #fff;
    border: 1px solid #fff;
    box-shadow: unset !important;
    font-family: RFlexRegular!important;
    min-width: 200px;
        }
    
        
    .right-sort {
       
        width: auto;
    float: unset;
    }
}
.filterbt-srt{
    background: #4a4a4a00;
    border-radius: 0;
    padding: 12px 15px;
    margin-bottom: 0;
    color: #fff;
    text-transform: capitalize;
    font-size: 16px;
    outline: none;
    border: 1px solid #FFf;
    border-radius: 2px;
    font-family: RFlexRegular!important;
    width: 250px;
}
.brandfilter {
    ${'' /* height: 300px;
  overflow: auto; */}

    position: absolute;
    width: 100%;
    background: #262626;
    border: 0px solid #DDDDDD;
    border-top: 0;
    height: auto;
    overflow: auto;

  li {
        color: #fff;
        &:hover{
            color:#FFBF56;           
            background: transparent;
        }
    }
}
.lsitngfilter {
    ${'' /* height: 300px;
  overflow: auto; */}

    position: absolute;
    width: 100%;
    background: #262626;
    border: 0px solid #DDDDDD;
    border-top: 0;
    height: 400px;
    overflow: auto;

  li {
        color: #fff;
        &:hover{
            color:#FFBF56;           
            background: transparent;
        }
    }
}
  /* width */
.lsitngfilter::-webkit-scrollbar {
    width: 2px;
}

/* Track */
.lsitngfilter::-webkit-scrollbar-track {
    background: #4A4A4A; 
}

/* Handle */
.lsitngfilter::-webkit-scrollbar-thumb {
    background: #FFBF56; 
}
.sortfilter{
    height: auto;
    position: absolute;
    width: 100%;
    background: #262626;
    border: 0px solid #FFBF56;
    border-top: 0;
  li {
        color: #fff;
        &:hover{
            color:#FFBF56;
        }
    }
}
span.filter {
    width: 50px;
    height: 50px;
    background: #F08601;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50px;
    box-shadow: 3px 3px 7px #00000047;
}
.sercblog {
    border: 1px solid #ddd;
    padding: 10px 14px;
    text-align: center;
    border-radius: 2px;
    margin-bottom: 15px !important;
   
}
.paginationbtn{
    text-align: center;
    padding: 15px 0;
}
.paginationbtn button {
    margin: 0 5px;
    width: 160px;
    padding: 8px 0;
    font-size: 16px;
    text-transform: capitalize;
    font-weight: 300 !important;
}
@media only screen and (max-width: 767px) {
    .filer_blog {       
        overflow: hidden;
        position: fixed;
        right: -100%;
        z-index: 9;
        background: #0E0E0E;
        width: 90%;
        height: 92vh;
        top: 57px;
        padding-top: 0px;
        overflow:auto;
        margin: 0;
        transition: 0.5s;
        box-shadow: -3px 0px 7px #0000001f;        
        border: 0;
        padding-bottom: 35px;
        display: block;
        div{
            padding:0px;
            border: 0;
        }
    }  
    .filer_blog .relative {
    margin-right: 0;
    display: block;
    margin-bottom: 9px;
}
.filer_blog .right-sort {
    width: 100%;
    float: unset;
}
 .filer_blog button {
    background: transparent;
    color: #fff;
    font-size: 16px;
    border: 0px solid #ddd;
    box-shadow: unset !important;
    font-family: RFlexRegular!important;
    border-bottom: 0px solid #ddd;
}
ul.sortfilter {
    border: 0;
    
    background: transparent;

}
.titlbar2 {
    background: transparent;
    h1 {
    margin-bottom: 0;
    font-size: 22px;
    text-transform: uppercase;
    color: #fff;
}
}
.lsitngfilter {
    height: unset;
    overflow: auto;
    position: relative;
    width: 100%;
    background: transparent;
}
.origin-top-left {
    position: relative;
    box-shadow: unset !important;
    border-bottom: 1px solid #ddd;
}
.titlbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0px;
    h1{
        margin-top:0px;
        
    }
  
}
svg.icons {
        font-size: 24px;
    }
.open{
    right:0px;
    transition: 0.5s;
    z-index: 99999;
    display: block;
}
 .filer_blog .filterbt {
    width: 100%;
    border: 0;
}
.filterbt-srt{
      width: 100%;
    border: 0;
}
.titlbar2 {
  
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 4px 12px !important;
    margin-bottom: 6px;
    border-bottom: 1px solid #ffc53a !important;
    h1 {
    margin-bottom: 0;
    font-size: 22px;
    text-transform: uppercase;
}
}
}
`;