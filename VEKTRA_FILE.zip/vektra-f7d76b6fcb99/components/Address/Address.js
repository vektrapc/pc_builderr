import React,{ FC,useState } from "react";
import s from "./Address.module.css"
import { Button, Button2 } from "@components/GlobalComponents/Button"
import { HiOutlineLocationMarker } from "react-icons/hi"
import { Logo, Input } from '@components/ui'
import { Row } from "@components/GlobalComponents/row"
import { Col_6,Col_12 } from "@components/GlobalComponents/Column"
import { RiPencilLine,RiDeleteBin7Line } from "react-icons/ri"
import Link from "next/link";
import { useForm } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";
import useCustomer from '../../framework/commerce/customer/use-customer'
import useAddress from '../../framework/commerce/customer/use-address'
import useRemoveAddress from '../../framework/shopify/customer/use-remove-address'
import Loader from "../Loader/Loader";
const schema = yup.object({
    first_name: yup.string().required(),
    last_name: yup.string().required(),
    company: yup.string().required(),
    address: yup.string().required(),
    appartment: yup.string().required(),
    city: yup.string().required(),
    country: yup.string().required(),
    province: yup.string().required(),
    zip_code: yup.string().required(),
    phone: yup.string().required(),
  }).required();
const MyAccount = () => {
    const [click,setState] = useState(false);
    const [loading, setLoading] = useState(false)
    const [message, setMessage] = useState('')
    const address = useAddress()
    const { data } = useCustomer()
    const {
        register,
        handleSubmit,
        control,
        setValue,
        getValues,
        setError,
        clearErrors,
        formState: { errors },
      } = useForm({ 
          mode: "onBlur", 
          resolver: yupResolver(schema),
        //   defaultValues: {
        //     firstName: "bill",
        //     lastName: "luo",
        //     company: "bluebill1049@hotmail.com",
        //     address: "bluebill1049@hotmail.com",
        //     appartment: "ddd",
        //     city: "ddd",
        //     country: "ddd",
        //     province: "ddd",
        //     zip_code: "ddd",
        //     phone: "ddd",
        //   }
         });
    const handles = () => {
        setState(!click);
    }
    const onSubmit = async(data) => {
       try {
        setLoading(true)
        setMessage('')
        await address({
            address1:data.address,  
            address2:data.province,  
            city:data.city,  
            company:data.company,  
            country:data.country,  
            firstName:data.firstName, 
            lastName:data.lastName, 
            phone:data.phone, 
            province:data.province, 
            zip:data.zip_code, 
          });
        setState(!click);
        setLoading(false);
        closeModal()
      } catch ({ errors }) {
          if(errors&& errors.length >0) {
            setMessage(errors[0].message)
          }
        setLoading(false);
      }
    };
    const handleDelete = (id) => {

    }
 
    const addressList = data?.addresses?.edges;

    return(
        <div className={s.root}>  
            { click ? (
                <div className={s.form}>
                      {message && (
          <div className="text-white border border-red p-3 bg-red">
            {message}
            {/* . Did you {` `}
            <a
              className="text-accent-9 inline font-bold hover:underline cursor-pointer"
              onClick={() => setModalView('FORGOT_VIEW')}
            >
              forgot your password?
            </a> */}
          </div>
        )}
                    <form onSubmit={handleSubmit(onSubmit)} autoComplete="off" >
                    <Row>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="First Name"
                            onChange={(val) => {
                                clearErrors('first_name')
                                setValue("first_name", val, { shouldDirty: true })}}
                              />
                              {errors.first_name && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    First Name is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            onChange={(val) => setValue("last_name", val, { shouldDirty: true })}
                            placeholder="Last Name"  
                            />
                            {errors.last_name && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Last Name is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="Company"
                            onChange={(val) => setValue("company", val, { shouldDirty: true })}
                              />
                              {errors.company && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Company Name is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="Address"  
                            onChange={(val) => setValue("address", val, { shouldDirty: true })}
                            />
                            {errors.address && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Address is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="Apartment, suite, etc."  
                            onChange={(val) => setValue("appartment", val, { shouldDirty: true })}
                            />
                            {errors.appartment && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    This field is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="City" 
                            onChange={(val) => setValue("city", val, { shouldDirty: true })}
                            />
                            {errors.city && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    City is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="Country/Region"
                            onChange={(val) => setValue("country", val, { shouldDirty: true })}
                            />
                            {errors.country && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Country is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="Province" 
                            onChange={(val) => setValue("province", val, { shouldDirty: true })}
                            />
                            {errors.province && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Province is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input type="text" placeholder="Postal/Zip Code" 
                            onChange={(val) => setValue("zip_code", val, { shouldDirty: true, required: true })}
                            />
                            {errors.zip_code && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Zip Code is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_6>
                            <Input 
                            type="text" 
                            placeholder="Phone"  
                            onChange={(val) => setValue("phone", val, { shouldDirty: true })}
                            />
                            {errors.phone && (
                                    <span style={{ color: "red", fontSize: "12px" }}>
                                    Phone Number is required.
                                    </span>
                                )}
                        </Col_6>
                        <Col_12 style={{textAlign:"center"}}>
                        <Button onClick={handleSubmit(onSubmit)}><span>Save  Address</span></Button>
                        </Col_12>
                    </Row>
                    </form>
                </div> 
            ): (
                <div>
                
              
                            {
                                addressList?.length>0 ?
                                        addressList?.map((address, index) => {
                                            const {node} = address;
                                            // console.log("address",address)
                                            return (
                                                <div className={s.addressShow} key={index}
                                                onClick={() => handleDelete(node.id)}
                                                >
                                                    <Row style={{justifyContent:"space-between"}}> 
                                                    <Col_6>
                                                        <div className={s.addreshow}>
                                                            <h2>{node?.firstName + ' ' +node?.lastName}</h2>
                                                            <p>
                                                            {node?.company} <br />
                                                            {node?.address1}<br />
                                                            {node?.address2}<br />
                                                            {node?.zip+" " + node?.city}<br />
                                                            {node?.country}
                                                            </p>
                                                        </div>
                                                    </Col_6>
                                                    <Col_6>
                                                        <div className={s.editbtn}>
                                                            <a><RiPencilLine className={s.edit}/></a>
                                                            <a><RiDeleteBin7Line className={s.del}/></a>
                                                        </div>
        
                                                    </Col_6>
                                                    </Row>
                                                </div>
                                            )
                                        })
                                
                            :
                            <div className={s.empty}>
                                <HiOutlineLocationMarker className={s.icons}/>
                                <p>You have not added any address!</p>
                            </div> 
                            }
                 

                    <div className={s.button}>               
                        <Link href="/myaccount"><Button2>Back</Button2></Link>
                        <a onClick={handles}><Button><span>Add New Address</span></Button></a>
                    </div>
                </div>
            )}
        </div>
    );
}
export default MyAccount;