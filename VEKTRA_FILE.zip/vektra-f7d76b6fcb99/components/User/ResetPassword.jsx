import React from 'react'
import { Container } from "@components/GlobalComponents/Container";
import { Spacing } from "@components/GlobalComponents/Spacing";
import { Logo, Input } from '@components/ui'
import { Button } from "@components/GlobalComponents/Button"
import s from "./User.module.css"
const ResetPassword = () => {
  return (
    <div className={s.root}>
        <Spacing>
            <Container>
                <div className={s.wrapper}>
                    <ul className={s.tabs}>
                        <li className={s.active} style={{width: "unset"}}>Reset Password</li>                                
                    </ul>
                    <div className="flex flex-col space-y-3">
            
                        <Input type="password" placeholder="Password"  />
                    
                        <Input type="password" placeholder="Confirm Password"  />
                        <br />
                        <Button   variant="slim" type="submit"  className="w-full sm-w-full text-center"><span>Submit</span></Button>   
                    </div>
                </div>
            
        
       
            </Container>
        </Spacing>
    </div>
  )
}

export default ResetPassword