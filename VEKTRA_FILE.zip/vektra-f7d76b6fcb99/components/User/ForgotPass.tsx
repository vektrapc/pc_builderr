import { Container } from "@components/GlobalComponents/Container";
import { Spacing } from "@components/GlobalComponents/Spacing";
import ForgotPassword from "@components/auth/ForgotPassword";
import s  from "./User.module.css";

import { FC, useState } from 'react'
import cn from 'classnames'
interface Props {
    className?: string
  }
  const ForgotPass: FC<Props> = ({ className }) => {
  
    return(
        <div className={cn(s.root, className)}>   
            <Container>
                <Spacing>
                    <div className={s.wrapper}>
                                <ul className={s.tabs}>
                                    <li className={s.active} style={{width: "unset"}}>Forgot Password</li>                                
                                </ul>
                     <ForgotPassword /> 
                    </div>
                </Spacing>                   
            </Container>  
        </div>
    );
}
export default ForgotPass;


