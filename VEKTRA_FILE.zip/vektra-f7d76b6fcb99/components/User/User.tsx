
import LoginPage from "@components/auth/LoginView"
import { Container } from "@components/GlobalComponents/Container";
import { Spacing } from "@components/GlobalComponents/Spacing";
import RegisterPage from "@components/auth/SignUpView"
import s from "./User.module.css"
import { FC, useState } from 'react'
import cn from 'classnames';
import { useRouter } from 'next/router'
interface Props {
    className?: string;
  }
  const User: FC<Props> = ({ className }) => {
        const router = useRouter()

      const [click,setState] = useState(router.pathname);
      const [click2,setState2] = useState(false);
      const login = () => {
        setState2(false); 
      }
      const register = () => {
        setState2(true); 
      }
    return(
        <div className={cn(s.root, className)}>   
            <Container>
                <Spacing>
                    <div className={s.wrapper}>
                    <ul className={s.tabs}>
                        <li className={click == "/login" ? s.active:""} onClick={() => router.push("/login")}>Login</li>
                        <li className={s.divder}></li>
                        <li className={click == "/register" ? s.active:""} onClick={() => router.push("/register")}>Register</li>
                    </ul>
                        {
                            click == "/login" ? (
                                <LoginPage /> 
                            ) : (
                                 <RegisterPage />
                            ) 
                        }
                       
                    </div>
                </Spacing>                   
            </Container>  
        </div>
    );
}
export default User;


