import React from "react";
import { Wrapper } from "./Breadcrumbs.Style"
import Link from "next/link";
import { MdKeyboardArrowRight } from "react-icons/md"
import { Container } from "@components/GlobalComponents/Container";
const Breadcrumbs = (props) =>{
    return(
        <React.Fragment>
            <Wrapper>  
                <Container>
                    <ul>
                        <li><Link href="/" >Home</Link> </li>
                        <li><MdKeyboardArrowRight  className="icons"/></li>
                        <li>{props.breadcrumbs}</li>
                    </ul>
                </Container>
            </Wrapper>
        </React.Fragment>
    );
}


export default Breadcrumbs;