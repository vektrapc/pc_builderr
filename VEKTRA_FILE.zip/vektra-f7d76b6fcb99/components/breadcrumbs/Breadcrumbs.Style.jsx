import styled from "styled-components";
export const Wrapper =  styled.div`
padding: 20px 0;
ul{
    display:flex;
    align-items:center;
   
    li{   
        color:#fff;
        font-size:14px;
        .icons{
            font-size: 20px;
        }
    }
}
@media only screen and (max-width: 767px) {
    padding:0px;
}
`;