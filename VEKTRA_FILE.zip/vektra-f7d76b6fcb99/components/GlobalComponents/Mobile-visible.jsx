import styled from "styled-components";
export const VisibleXS = styled.div`
display:none;
  @media (max-width: 992px) {
    display:none;
  }
  @media (max-width: 576px) {
    display:block;
  }
  @media (max-width: 767px) {
    display:block;
  }

`;