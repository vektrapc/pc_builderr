import styled from "styled-components";

export const SelectBox = styled.select`
    
        border: 2px solid #A4A4A4;
        width: 100%;
        background: transparent;
        padding: 7px 14px;
        font-size: 18px;
        color: #fff;
        outline:none;
        &:focus{
            
        border-color: #7F4A07;
        }
    option{
        color:#000;
    }

`;