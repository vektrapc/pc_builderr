import styled from "styled-components"

export const Spacing = styled.div`
padding : 25px 0;

`;