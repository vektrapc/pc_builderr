import styled from "styled-components";

export const Heading1 = styled.h1`
    font-size: 45px;
    color: #fff;
    margin-bottom: 15px;
    line-height: 50px;
@media only screen and (max-width: 767px) {
    font-size: 30px ;
    line-height: 40px ;
}
`;

export const Heading2 = styled.h2`
    font-size: 18px;
    color:#fff; 
`;

export const Heading3 = styled.h3`
    font-size: 18px;
`;