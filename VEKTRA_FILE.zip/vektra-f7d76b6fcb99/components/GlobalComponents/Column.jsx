import styled from "styled-components";

export const Col_3 = styled.div`
   padding:0 15px;
    width: 25%; 
    flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width: 25%;
    flex:0 0 auto;

  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 25%;
    flex:0 0 auto;

  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;

export const Col_4 = styled.div`
   padding:0 15px;
    width: 33.3%; 
    flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width: 33.3%;
    flex:0 0 auto;

  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 33.3%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;

export const Col_5 = styled.div`
   padding:0 15px;
   flex:0 0 auto;
   width:41.66666667%;
   
  @media (max-width: 992px) {
    padding:0 15px;
    flex:0 0 auto;
    width:41.66666667%;
  
  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 50%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;

export const Col_6 = styled.div`
   padding:0 15px;
    width: 50%; 
    flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width: 50%;
    flex:0 0 auto;

  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 50%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;
export const Col_7 = styled.div`
   padding:0 15px;
    width: 58.33333333%; 
    flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width: 58.33333333%; 
    flex:0 0 auto;

  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 100%; 
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;
export const Col_8 = styled.div`
   padding:0 15px;
   width:66.66666667%;
   flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width:66.66666667%;
    flex:0 0 auto;

  }
  @media (max-width: 576px) {
    padding:0 15px;
    width:100%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;

export const Col_9 = styled.div`
   padding:0 15px;
   width:75%;
   flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width:75%
  }
  @media (max-width: 576px) {
    padding:0 15px;
    width:100%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
  
`;

export const Col_10 = styled.div`
   padding:0 15px;
    width: 83.33333333%; 
    flex:0 0 auto;

  @media (max-width: 992px) {
    padding:0 15px;
    width: 83.33333333%;
  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 50%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;



export const Col_11 = styled.div`
   padding:0 15px;
   flex:0 0 auto;

    width: 91.66666667%; 
  @media (max-width: 992px) {
    padding:0 15px;
    width: 91.66666667%;
  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 50%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;

export const Col_12 = styled.div`
   padding:0 15px;
    width: 100%; 
  @media (max-width: 992px) {
    padding:0 15px;
    width: 100%;
  }
  @media (max-width: 576px) {
    padding:0 15px;
    width: 100%;
  }
  @media (max-width: 767px) {
    width: 100%;
  }
`;



