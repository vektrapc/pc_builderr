import styled from "styled-components";

export const Row = styled.div`
    display:flex;
   margin-left:-15px;
   margin-right:-15px;
    flex-wrap: wrap;

 
  @media (max-width: 992px) {
    display:flex;
  }
  @media (max-width: 576px) {
    display:block;
  }
  @media (max-width: 767px) {
    display:block;
  }
`;
