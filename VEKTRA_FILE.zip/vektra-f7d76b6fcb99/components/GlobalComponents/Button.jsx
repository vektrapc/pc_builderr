import styled from "styled-components";
export const Button = styled.button`
    border: 1px solid  #FFC53A;
    padding: 10px 20px;
    font-size: 18px;
    text-transform: uppercase;
    color: #242E38;
    border-radius: 50px;
    position: relative;
    transition: 0.5s;
    overflow: hidden;
    outline: none !important;
    background: #fff;
    span{
        position: relative;
    }
    &::before{
        content:"";
        background: #FFC53A;
        width:100%;
        height:100%;
        position: absolute;
        right:0;
        top:0;
        transition: 0.5s;
    }
  
    &:hover:before{
        width:0%;
    }
    &[disabled]{
        cursor: not-allowed;
        border-color: #374151;
        &::before, &:hover::before{
            content:"";
            background: #9ca3af;
            width:100%;
            height:100%;
            position: absolute;
            right:0;
            top:0;
            transition: 0.5s;
        }
      
    }

@media only screen and (max-width: 1024px){
        font-size: 16px !important;
}

@media only screen and (max-width: 767px){
        font-size: 16px !important;
}
`;

export const Button2 = styled.button`
      border: 1px solid  #fff;
    padding: 10px 20px;
    font-size: 18px;
    text-transform: uppercase;
    color: #242E38;
    border-radius: 50px;
    position: relative;
    transition: 0.5s;
    overflow: hidden;
    outline: none !important;
    background: #fff;
    &:hover{
        color:#FFC53A;
    }
    
@media only screen and (max-width: 1024px){
        font-size: 16px !important;
}

@media only screen and (max-width: 767px){
        font-size: 16px !important;
}
`;