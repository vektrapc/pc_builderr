import styled from "styled-components";
export const HiddenXS = styled.div`
display:block;
  @media (max-width: 992px) {
    display:block;
  }
  @media (max-width: 576px) {
    display:none;
  }
  @media (max-width: 767px) {
    display:none;
  }

`;