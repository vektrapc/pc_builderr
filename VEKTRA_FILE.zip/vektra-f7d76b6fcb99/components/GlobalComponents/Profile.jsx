import styled from "styled-components";
export const ProfileStyle = styled.div`
    background: #252525;
    padding: 30px 37px;
    .profileblog {
        width:100%;
        max-width: 450px;
        margin: 0 auto;
        display: block;
        h2{
            font-size: 28px;
            color: #fff;
            margin-bottom: 20px;
            font-family: "RFlexRegular";
            text-align: center;
        }
    }
    .procontent {
        p {
            font-size: 16px;
            margin-bottom: 0;
            text-transform: uppercase;
           
            }
        span {
            display: block;
            border-bottom: 2px solid #525252;
            padding: 10px 0;
            text-transform: capitalize;
            font-size: 16px;
            color: #b3b1b1;
        }
    }
    .lowercase {
        span {
            display: block;
            border-bottom: 2px solid #525252;
            padding: 10px 0;
            text-transform: lowercase;
            font-size: 16px;
            color: #b3b1b1;
        }
    }
    button{
        margin: 0 auto;
    display: block;
    padding-left: 50px;
    padding-right: 50px;
    }

`;