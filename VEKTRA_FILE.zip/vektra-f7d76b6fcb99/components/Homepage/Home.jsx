import React from 'react'
import Hero from './Herosection/Hero'
import Feature from './Features/Features'
import NewIn from './NewIn/Newin'
import Tranding from './TrandingPcs/Trading'
import Upgrade from './UpgradePc/Upgrade'
const Home = ({ homedata }) => {
  const { banners, hero_data, upgradepc_data } = homedata
  return (
    <React.Fragment>
      <Hero data={hero_data} />
      <Feature data={hero_data} />
      <NewIn banners={banners} />
      <Tranding data={hero_data} />
      <Upgrade data={upgradepc_data} />
    </React.Fragment>
  )
}

export default Home
