import React from 'react';
import {SiTrustpilot} from "react-icons/si"
import Link from "next/link"
const TrustBox = () => {
  // Create a reference to the <div> element which will represent the TrustBox
  const ref = React.useRef(null);
  React.useEffect(() => {
// If window.Trustpilot is available it means that we need to load the TrustBox from our ref.
// If it's not, it means the script you pasted into <head /> isn't loaded  just yet.
// When it is, it will automatically load the TrustBox.
if (window.Trustpilot) {
  window.Trustpilot.loadFromElement(ref.current, true);
}
  }, []);
  return (
    <>
<div
  ref={ref} 
  class="trustpilot-widget" 
  data-locale="en-US" 
  data-template-id="5419b6a8b0d04a076446a9ad" 
  data-businessunit-id="5fd05ff413159100018c6835" 
  data-style-height="30px" data-style-width="100%" 
  data-theme="dark" data-min-review-count="10"
>
  <a href="https://www.trustpilot.com/review/vektrapc.com" target="_blank" rel="noopener">Trustpilot</a>
</div>
<a href="https://www.trustpilot.com/review/vektrapc.com" target="_blank"  className="reviewbtn">Review us on <SiTrustpilot className="icons" />Trustpilot</a>
</>
  );
};
export default TrustBox;