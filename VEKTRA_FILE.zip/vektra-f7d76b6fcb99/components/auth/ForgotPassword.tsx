import { FC, useEffect, useState, useCallback } from 'react'
import { validate } from 'email-validator'
import { useUI } from '@components/ui/context'
import { Logo,  Input } from '@components/ui'
import Button  from "@components/ui/Button"
import Link from "next/link"
import useRecover from '../../framework/shopify/auth/use-recover'

interface Props {}

const ForgotPassword: FC<Props> = () => {
  // Form State
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [dirty, setDirty] = useState(false)
  const [disabled, setDisabled] = useState(false)
  const recover = useRecover()
  const { setModalView, closeModal } = useUI()

  const handleResetPassword = async (e: React.SyntheticEvent<EventTarget>) => {
    e.preventDefault()

    if (!dirty && !disabled) {
      setDirty(true)
      handleValidation()
      
    }else {
      try {
        setLoading(true)
        setMessage('')
        await recover({
          email,
        })
        setLoading(false)
      } catch ({ errors }) {
        setMessage(errors[0].message);
        setLoading(false);
      }
    }
  }

  const handleValidation = useCallback(() => {
    // Unable to send form unless fields are valid.
    if (dirty) {
      setDisabled(!validate(email))
    }
  }, [email, dirty])

  useEffect(() => {
    handleValidation()
  }, [handleValidation])

  return (
    <form
      onSubmit={handleResetPassword}
      className=""
    >
      {/* <div className="flex justify-center pb-12 ">
        <Logo width="64px" height="64px" />
      </div> */}


      <div className="flex flex-col space-y-4">
        {message && (
          <div className="text-white border border-red p-3 bg-red">{message}</div>
        )}

        <Input placeholder="Email" onChange={setEmail} type="email" />
        <div className="pt-2 w-full flex flex-col">
          <Button
           
            type="submit"
           
          >
           <span> Recover Password</span>
          </Button>
        </div>

        {/* <span className="pt-3 text-center text-sm">
          <span className="">Do you have an account?</span>
          {` `}
         <Link href="/login"><a
            className="font-bold hover:underline cursor-pointer"
           
          >
            Log In
          </a></Link>
        </span> */}
      </div>
    </form>
  )
}

export default ForgotPassword
