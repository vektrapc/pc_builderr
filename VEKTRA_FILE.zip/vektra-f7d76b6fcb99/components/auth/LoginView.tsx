import { FC, useEffect, useState, useCallback } from 'react'
import { Logo, Input } from '@components/ui'
import useLogin from '../../framework/shopify/auth/use-login'
import { useUI } from '@components/ui/context'
import { validate } from 'email-validator'
import Button from "@components/ui/Button"
import Link from "next/link"
import Social from "@components/common/SocialIcons"
import s from "../common/SocialIcons/SocialMedia.module.css"
import GoogleLogin from 'react-google-login';
import useCustomer from '@framework/customer/use-customer';
import { useRouter } from 'next/router'
// import FacebookLogin from 'react-facebook-login';
// @ts-ignore
import FacebookLogins from 'react-facebook-login/dist/facebook-login-render-props'
import { toast } from 'react-toastify';
import { FaFacebookF,FaGooglePlusG } from "react-icons/fa"
interface Props {}

const LoginView: FC<Props> = () => {
  // Form State
  const { data } = useCustomer();
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [dirty, setDirty] = useState(false)
  const [disabled, setDisabled] = useState(false)
  const { setModalView, closeModal } = useUI()

  const login = useLogin()

  const handleLogin = async (e: React.SyntheticEvent<EventTarget>) => {
    e.preventDefault()

    if (!dirty && !disabled) {
      setDirty(true)
      handleValidation()
    }

    try {
      setLoading(true)
      setMessage('')
      await login({
        email,
        password,
      })
      setLoading(false)
      closeModal()
    } catch ({ errors }) {
      setMessage(errors[0].message)
      setLoading(false)
    }
  }

  const handleValidation = useCallback(() => {
    // Test for Alphanumeric password
    const validPassword = /^(?=.*[a-zA-Z])(?=.*[0-9])/.test(password)

    // Unable to send form unless fields are valid.
    if (dirty) {
      setDisabled(!validate(email) || password.length < 7 || !validPassword)
    }
  }, [email, password, dirty])

  const responseGoogle = async(response: any) => {
    const { email, familyName, givenName, googleId, name} = response.profileObj
    try {
      setLoading(true)
      setMessage('')
      await login({
        email: email,
        password: googleId,
      })
      setLoading(false)
      closeModal()
    } catch ({ errors }) {
      console.log(errors)
      setMessage(errors[0].message)
      setLoading(false);
    }
  }
  const responseFailedGoogle = (response: any) => {
  //   toast.error("Login Failed" , {
  //     position: "bottom-right",
  //     autoClose: 5000,
  //     hideProgressBar: false,
  //     closeOnClick: true,
  //     pauseOnHover: true,
  //     draggable: true,
  //     progress: undefined,
  // });
  }

    //Facebook Login Start
    const responseFacebook = async(response: any) => {
      console.log("response", response);
      if( response.status !== "unknown") {
        const {email, name, id} = response;
        setEmail(email)
        setPassword(id)
        if(email) {
          try {
            setLoading(true)
            setMessage('')
            await login({
              email: email,
              password: id,
            })
            setLoading(false)
            closeModal()
          } catch ({ errors }) {
            console.log("errors", errors)
            setMessage(errors[0].message)
            setLoading(false)
          }
        }
      }
    }

  useEffect(() => {
    handleValidation()
    console.log("data", data)
    if(data) {
      router.push('/myaccount');
    }
  }, [handleValidation,data])

  return (
    <form
      onSubmit={handleLogin}
      className=""
    >
      {/* <div className="flex justify-center pb-12 ">
        <Logo width="64px" height="64px" />
      </div> */}
      <div className="flex flex-col space-y-3">
        {message && (
          <div className="text-white border border-red p-3 bg-red">
            {message}
            {/* . Did you {` `}
            <a
              className="text-accent-9 inline font-bold hover:underline cursor-pointer"
              onClick={() => setModalView('FORGOT_VIEW')}
            >
              forgot your password?
            </a> */}
          </div>
        )}
        <Input value={email} type="email" placeholder="Email" onChange={setEmail} />
        <Input value={password} type="password" placeholder="Password" onChange={setPassword} />
          <div className="flex  pt-3 items-center	justify-between	block">
            <div className="mb-3">
              <input type="checkbox" />  &nbsp; Remember Me
            </div>
            <Button
           
            type="submit"
           
            className="w-3/5 sm-w-full"
          ><span>
            Log In
          </span>
          
          </Button>
          </div>
        
        <div className="pt-2 text-center ">
          <Link href="forgot" passHref>
        <a
              className="text-accent-9 inline hover:underline cursor-pointer"
              
            style={{color:"#FFC53A"}}>
              Forgot Your Password?
            </a>
            </Link>
        
         
        </div>
        <GoogleLogin
          clientId="311687515169-hpqk1a6ort0e3k7979c23s634p7v9bfu.apps.googleusercontent.com"     
          render={renderProps => (      
            <a className={s.google} onClick={renderProps.onClick} 

            // disabled={renderProps.disabled}
            ><FaGooglePlusG className={s.icons}/>  Login with Google</a>
          
          )}
          buttonText="Login"
          onSuccess={responseGoogle}
          onFailure={responseFailedGoogle}
          cookiePolicy={'single_host_origin'}
        />
          <FacebookLogins
          appId="1425039297944220"
          autoLoad={false}
          fields="name,email,picture"
          callback={responseFacebook}
          onFailure={(err:any) => {
            console.log("err", err)
          }}
          render={(renderProps:any) => (
            <a className={s.facebook} onClick={renderProps.onClick}><FaFacebookF className={s.icons}/> Login With Facebook</a>
          )}
        />

          
      </div>
    </form>
  )
}

export default LoginView
