import { FC, useEffect, useState, useCallback } from 'react'
import { validate } from 'email-validator'
import { Info } from '@components/icons'
import { useUI } from '@components/ui/context'
import { Logo,  Input } from '@components/ui'
import useSignup from '../../framework/shopify/auth/use-signup'
import Button from "@components/ui/Button"
import Social from "@components/common/SocialIcons"
import GoogleLogin, { useGoogleLogout} from 'react-google-login';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css'
import { Wrapper } from "./Sign.Style"
import useCustomer from '@framework/customer/use-customer';
import { useRouter } from 'next/router'
// import FacebookLogin from 'react-facebook-login';
// import FacebookLogin from 'react-facebook-login';
// @ts-ignore
import { toast } from 'react-toastify';
import { FaFacebookF,FaGooglePlusG } from "react-icons/fa"
import s from "../common/SocialIcons/SocialMedia.module.css"
// import {} from "../../components/Configurator/Form/From.Style.jsx"
import FacebookLogins from 'react-facebook-login/dist/facebook-login-render-props'
interface Props {}

const SignUpView: FC<Props> = () => {
  // Form State
  const { data } = useCustomer();
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [dirty, setDirty] = useState(false)
  const [disabled, setDisabled] = useState(false);
  const [countryCode, setCountryCode] = useState("ae");
  const { signOut } = useGoogleLogout({
    clientId: "311687515169-hpqk1a6ort0e3k7979c23s634p7v9bfu.apps.googleusercontent.com"     ,
    onLogoutSuccess: (() => {
      console.log("logout success")
    })
  })
  useEffect(() => {
    fetch('http://www.geoplugin.net/json.gp?ip=')
    .then( res => res.json())
    .then(response => {
        if(response.geoplugin_status === 200){
            setCountryCode(response.geoplugin_countryCode)
        }
      })
  },[0])
  const signup = useSignup()
  const { setModalView, closeModal } = useUI()

  const handleSignup = async (e: React.SyntheticEvent<EventTarget>) => {
    e.preventDefault()
    let number = phone.trim();
    number= number.replace("-","");
    number = number.replace(/[\])}[{(]/g, '');
    
    number= number.replace(/ /g,'')
    console.log("number",number)
    if (!dirty && !disabled) {
      // setDirty(true)
      handleValidation()
    }
    try {
      setLoading(true)
      setMessage('')
      await signup({
        email,
        firstName,
        lastName,
        password,
        phone: number,
      })
      setLoading(false)
      closeModal()
    } catch ({ errors }) {
      setMessage(errors[0].message)
      setLoading(false)
    }
  }
  const responseGoogle = async(response: any) => {
    const { email, familyName, givenName, googleId, name} = response.profileObj
    setFirstName(givenName)
    setLastName(familyName)
    setEmail(email)
    setPassword(googleId)
    let number = phone.trim();
    number= number.replace("-","");
    number = number.replace(/[\])}[{(]/g, '');
    
    number= number.replace(/ /g,'')
    try {
      setLoading(true)
      setMessage('')
      await signup({
        email: email,
        firstName: givenName,
        lastName: familyName,
        password: googleId,
        phone: number,
      })
      setLoading(false)
      closeModal()
    } catch ({ errors }) {
      console.log("number",errors)
      setMessage(errors[0].message);
      signOut()
      setLoading(false)
      // switch(errors[0].code) {
      //   case "TAKEN": {
      //       toast.error(errors[0].message , {
      //           position: "bottom-right",
      //           autoClose: 5000,
      //           hideProgressBar: false,
      //           closeOnClick: true,
      //           pauseOnHover: true,
      //           draggable: true,
      //           progress: undefined,
      //       });
      //       router.push('/login');
      //   }
      //     // code block
      //     break;
      //   case "INVALID":
      //     // code block
      //     break;
      //   default:
      //     // code block
      // }
    }
  }
  const responseFailedGoogle = (response: any) => {
    toast.error("Login Failed" , {
      position: "bottom-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
  });
  };
  //Facebook Signup Start
  const responseFacebook = async(response: any) => {
    console.log("response", response);
    if( response.status !== "unknown") {
      const {email, name, id} = response
      let splitName = name.split(" ");
      setFirstName(splitName[0])
      setLastName(splitName[1])
      setEmail(email)
      setPassword(id)
      let number = phone.trim();
    number= number.replace("-","");
    number = number.replace(/[\])}[{(]/g, '');
    number= number.replace(/ /g,'');
    if(email) {  
      try {
        setLoading(true)
        setMessage('')
        await signup({
          email: email,
          firstName: splitName[0],
          lastName: splitName[1],
          password: id,
          phone: number,
        })
        setLoading(false)
        closeModal()
      } catch ({ errors }) {
        console.log("errors", errors)
          setMessage(errors[0].message);
          setLoading(false)
      }
      }
    }
  }
  const handleValidation = useCallback(() => {
    // Test for Alphanumeric password
    const validPassword = /^(?=.*[a-zA-Z])(?=.*[0-9])/.test(password)

    // Unable to send form unless fields are valid.
    if (dirty) {
      setDisabled(!validate(email) || password.length < 7 || !validPassword)
    }
  }, [email, password, dirty])

  useEffect(() => {
    handleValidation()
    if(data) {
      router.push('/myaccount');
    }
  }, [handleValidation,data])

  return (
    <Wrapper>
    <form
      onSubmit={handleSignup}
      className=""
    >
      {/* <div className="flex justify-center pb-12 ">
        <Logo width="64px" height="64px" />
      </div> */}
      <div className="flex flex-col space-y-4">
        {message && (
          <div className="text-white border border-red p-3 bg-red">{message}</div>
        )}
        <Input 
        value={firstName}
        placeholder="First Name" onChange={setFirstName} />
        <Input value={lastName} placeholder="Last Name" onChange={setLastName} />
        <Input value={email} type="email" placeholder="Email" onChange={setEmail} />
        <div className="phone-filed">
        <PhoneInput
          country={countryCode.toLowerCase()}
                                onChange={(value, country, e, mobile_no) => {
                               
                                  setPhone(mobile_no);
                                  }
                                }
                                inputStyle={{
                                    width: '100%',
                                    padding: '15px 15px 15px 50px',
                                    border: 'none',
                                    borderBottom: '2px solid #525252',
                                    borderRadius: '8px',
                                    height: 'auto',
                                    boxShadow: 'none',
                                    background:"#fff",
                                    color:' #444444',
                                    fontSize: '16px',
                                    fontFamily: "RFlexBold"

          }}
        />
      </div>
        <Input value={password} type="password" placeholder="Password" onChange={setPassword} />
        {/* <span className="">
          <span className="inline-block align-middle ">
            <Info width="15" height="15" />
          </span>{' '}
          <span className="leading-6 ">
            <strong>Info</strong>: Passwords must be longer than 7 chars and
            include numbers.{' '}
          </span>
        </span> */}
        <div className="pt-2 w-full flex flex-col">
          <Button
            
            type="submit"
           
          ><span> Sign Up</span>
           
          </Button>
        </div>

        {/* <span className="pt-1 text-center text-sm">
          <span className="text-accent-7">Do you have an account?</span>
          {` `}
          <a
            className="text-accent-9 font-bold hover:underline cursor-pointer"
            onClick={() => setModalView('LOGIN_VIEW')}
          >
            Log In
          </a>
        </span> */}
        {/* <Social facebook="Register With Facebook" google="Register With Google" /> */}
        <div className="pt-2 w-full flex flex-col">
        <GoogleLogin
            clientId="311687515169-hpqk1a6ort0e3k7979c23s634p7v9bfu.apps.googleusercontent.com"     
            buttonText="Login with Google"
            onSuccess={responseGoogle}
            // onFailure={responseFailedGoogle}
            render={renderProps => (      
              <a className={s.google} onClick={renderProps.onClick} 
  
              // disabled={renderProps.disabled}
              ><FaGooglePlusG className={s.icons}/>  Signup with Google</a>
            
            )}
            // cookiePolicy={'single_host_origin'}
            
          />
          <FacebookLogins
            appId="1425039297944220"
            autoLoad={false}
            fields="name,email,picture"
            scope="public_profile, email"
            cssClass="my-facebook-button-class"
            callback={responseFacebook} 
            render={(renderProps:any) => (
              <a className={s.facebook} onClick={renderProps.onClick}><FaFacebookF className={s.icons}/> Signup With Facebook</a>
            )}
          />
        </div>
        
      </div>
    </form>
      </Wrapper>
  )
}

export default SignUpView
