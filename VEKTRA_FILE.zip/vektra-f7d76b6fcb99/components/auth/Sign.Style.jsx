import styled from "styled-components";
export const Wrapper = styled.div`
    padding: 10px 0 50px;
.form {
    background: #0E0E0E;
    padding: 40px 24px;
    text-align: center;
    h2{
        font-size: 28px;
        color: #fff;
        margin-bottom: 20px;
        font-family: "RFlexRegular"
    }
    .form-group {
    margin-bottom: 20px;
        input , select {
            text-transform: lowercase;
            border-bottom: 2px solid #525252;
            width: 100%;
            max-width: 400px;
            margin-bottom: 0;
            text-align: left;
            background: transparent;
            font-size: 18px;
            padding: 10px 0;
            font-family: "RFlexRegular";
            color:#fff;
            outline:none;
            &:focus{
                border-color:#7F4A07;
            }
            &::placeholder{
                color:#4A4A49;
            }
           
        }
    }
    button{
        margin-top: 15px;

    }
}

.special-label {
    display: none;
}

 .react-tel-input .selected-flag .arrow {
    text-transform: lowercase;
    border-bottom: 1px solid #000 !important;
    border-right: 1px solid #000 !important; 

}
.form-group {
    margin-bottom: 20px;
        input , select {
            text-transform: lowercase;
            border-bottom: 2px solid #525252;
            width: 100%;
            max-width: 400px;
            margin-bottom: 0;
            text-align: left;
            background: #fff;
            font-size: 18px;
            padding: 10px 0;
            font-family: "RFlexRegular";
            color:#000;
            outline:none;
            &:focus{
                border-color:#7F4A07;
            }
            &::placeholder{
                color:#f2f2f2;
            }
           
        }
    }
.customselect{
    width:100%;
    max-width:400px;
    margin:0 auto;
    text-align: left;
}
.menu-flags-button {
    border: 0;
    border-bottom: 2px solid #525252;
    border-radius: 0;
    color: #fff;
    font-weight: 400 !important;
    padding-left:0px;
}
.menu-flags ul {
    overflow-x: hidden;
    background: #727272;
    border: 0;
    max-height: 300px ;
    box-shadow: 1px 5px 9px #00000042;
}
.menu-flags ul li {
    color: #fff;
    &:hover{
        background:#0E0E0E;
    }
}
.menu-flags ul div input {
    border: 0;
    border-bottom: 1px solid #afafaf !important;
    margin-left: 0;
    padding-left: 15px !important;
    text-transform: lowercase;
}
.menu-flags ul div {
    background: #727272;
    padding-top: 0;
}
.menu-flags-button span {
    font-weight: 400 !important;
    font-family: "RFlexRegular" !important;
    padding-left:0px;
}
.menu-flags-button svg {
margin-right: 10px;
}
.menu-flags-button[aria-expanded="true"]:after {
    border-top: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-bottom: 5px solid #4d4d4d;
    border: 0;
    width: 8px;
    height: 8px;
    background: transparent;
    border-top: 1px solid #fff;
    border-left: 1px solid #fff;
    transform: rotate(
45deg);
}

.menu-flags-button[aria-expanded="false"]:after {
    border-top: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-bottom: 5px solid #4d4d4d;
    border: 0;
    width: 8px;
    height: 8px;
    background: transparent;
    border-bottom: 1px solid #fff;
    border-right: 1px solid #fff;
    transform: rotate(
45deg);
}
/* width */
.menu-flags ul::-webkit-scrollbar {
  width: 5px;
  height:10px;
}

/* Track */
.menu-flags ul::-webkit-scrollbar-track {
    background: #727272;
}

/* Handle */
.menu-flags ul::-webkit-scrollbar-thumb {
 
  background: #FFC53A;
}
.selected-flag {
    background: transparent !important;
    border: 0 !important;
}
 .react-tel-input .flag-dropdown {
    border: 0;
    background: transparent;
    text-transform: lowercase;
}
.react-tel-input .selected-flag .arrow {
    text-transform: lowercase;
    border: 0;
    width: 5px;
    height: 5px;
    border-bottom: 1px solid #fff;
    border-right: 1px solid #fff;
    transform: rotate(
45deg);
    margin-left: 4px;
    margin-top: -4px;
}
.react-tel-input .selected-flag .arrow.up {
    text-transform: lowercase;
    border-bottom: 0px solid #fff;
    border-right: 0px solid #fff;
    border-top: 1px solid #fff;
    border-left: 1px solid #fff;
    margin-top: 0px;
}

.country-list .country.highlight {
    background: #0E0E0E !important;
}

.react-tel-input .country-list .country {
    text-transform: lowercase;
    padding: 9px 9px;
    font-size: 14px;
}
ul.country-list {
    background: #4A4A49 !important;
    li{
        span{
            color:#fff !important;
        }
        &:hover{
            background:#0E0E0E !important;
        }
    }
}
ul.country-list {
    min-width: 404px !important;
    width: auto !important;
    /* width */
    &::-webkit-scrollbar {
    width: 5px;
    height:10px;
    }

    /* Track */
    &::-webkit-scrollbar-track {
        background: #727272;
    }

    /* Handle */
    &::-webkit-scrollbar-thumb {
    
    background: #FFC53A;
    }
}


@media only screen and (max-width:767px) {
     ul.country-list {
    min-width: 300px !important;
    width: auto !important;
}
}
`;