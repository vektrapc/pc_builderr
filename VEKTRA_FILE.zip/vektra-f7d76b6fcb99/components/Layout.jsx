import React from "react";
import Head from "next/head";


const Layout = (props) => {
  return (
    <React.Fragment>
      <Head>
        <title>{props.title}</title>
      </Head>
      {props.children}
    </React.Fragment>
  );
};

export default Layout;
