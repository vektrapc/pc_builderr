import React,{ useRef } from "react";
import Header from "./Header/Header";
import Footer from "./Footer/Footer";
import Mobileheader from "./Header/HeaderResponsive"


const GlobalLayout = (props) => {
  const myRef = useRef(null);
  
  return (
    <React.Fragment>
      <Header />
      <Mobileheader />
      <div className="mobile_scrollingview"  >
          <div>{props.children}</div>
      </div>  
      <Footer />  
    </React.Fragment>
  );
};

export default GlobalLayout;
