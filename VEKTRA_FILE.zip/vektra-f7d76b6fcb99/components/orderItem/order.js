import React, { FC,useState } from "react"
import s from "./order.module.css"
import Collapse from "../ui/Collapse"
import { Image } from "../GlobalComponents/Image"
import { Button, Button2 } from "../GlobalComponents/Button"
import Cookies from 'js-cookie';
import { useRouter } from 'next/router';
import  { Wrapper } from "./order.Style"
import Loader from "../Loader/Loader";
import { useAddItem } from '@framework/cart'
import {Text, Rating, useUI } from '@components/ui';
import Link from "next/link";
import useCustomer from '@framework/customer/use-customer'
import { findPhoneNumbersInText } from 'libphonenumber-js'
import { toast } from 'react-toastify';

const  item = [
    {
        name:"Corsair 4000D Airflow",
        image:"/images/case.png",
        price:"450.00"
    },
    {
        name:"Corsair 3000D Airflow",
        image:"/images/case.png",
        price:"450.00"
    }
]
const items = [
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
]

const Order = (props) => {
    const [loading, setLoading] = useState(false)
    const router = useRouter();
    const addItem = useAddItem();
    const [buildName, setBuildName] = useState("");
    const { data } = useCustomer()
    const [showError, setShowError] = useState(false);
    const { toggleSidebar, closeSidebarIfPresent, openModal, addBuildToCart} = useUI()
    const builds = props.builds;
    const refreshData = () => {
        router.replace(router.asPath);
    }
    const addItemToCart = async(values) => {
        await addItem({
          productId: btoa('gid://shopify/product/'+values.store_product_id),
          variantId: btoa('gid://shopify/ProductVariant/'+values.store_variant_id),
        })
      }
      const addItemToCart2 = async(values, attr) => {
        console.log("attr", attr)
        await addItem({
          productId: btoa('gid://shopify/product/'+values.store_product_id),
          variantId: btoa('gid://shopify/ProductVariant/'+values.store_variant_id),
          customAttributes: attr,
        })
    }
      //old
    // const addToCart = async (conf_api_res) => {
    //     setLoading(true)
    //     const saved_builds = Cookies.get("saved_builds");
    //     let saved_builds_parse = [];
    //     if(saved_builds) {
    //         saved_builds_parse = JSON.parse(saved_builds)
    //     }
    //     saved_builds_parse.filter(item => item.build_token != conf_api_res?.build_token)
    //    let quantity = 1
    //     if(conf_api_res?.build_token) {
    //         const formdata = new FormData();
    //         formdata.append("enquiry_token", conf_api_res?.enquiry_token );
    //         formdata.append("build_token", conf_api_res?.build_token );
    //         formdata.append("build_quantity", quantity );
    //         formdata.append("is_build_added_cart", 1 );
    //         const STORECONFIGPCAPIURL = process.env.NEXT_PUBLIC_API_URL + "/store-configurator-pc-data";
    //         const res = await fetch(STORECONFIGPCAPIURL, {
    //         method: "POST",
    //         body: formdata,
    //         });
    //         let result;
    //         try {
    //              result = await res.json();
    //             if (result.status === true) {
    //                 setQuantity(quantity+1)
    //                 Cookies.set("build_token", result.build_token, { expires: 7 });
    //             }

    //         } catch(error) {
             
    //         }
    //         let builds = [];
    //         //new
    //         let buildCartData = {};
    //         let build_tokens = [];
    //         let foundBuild = false
    //         let savedBuildCartData = localStorage.getItem("buildCartData")
    //         if(savedBuildCartData) {
    //             buildCartData = JSON.parse(savedBuildCartData)
    //         }
    //         if(Object.keys(buildCartData).length === 0) {
    //             build_tokens.push(result.build_token)
    //             buildCartData["enquiry_token"] = conf_api_res?.enquiry_token
    //             buildCartData["build_token"] = build_tokens
    //         } else {
    //             build_tokens = buildCartData["build_token"];
    //             if(build_tokens.length > 0) {
    //                 build_tokens.forEach(item => {
    //                     if(item == result.build_token) {
    //                         foundBuild = true
    //                     }
    //                 })
    //             }
    //             if(!foundBuild) {
    //                 build_tokens.push(result.build_token)
    //             }
    //             buildCartData["build_token"] = build_tokens
    //         }
       
    //         localStorage.setItem("buildCartData", JSON.stringify(buildCartData)) 
    //         addBuildToCart(buildCartData);
    //         async function make_api_call(item){
    //             await addItemToCart(item);
    //         }
    //         async function processBuildsToCart(){
    //             for(let i = 0; i < conf_api_res.selected_variant_data.length; i++){
    //                 await make_api_call(conf_api_res.selected_variant_data[i]);
    //             }
    //         }
    //         await processBuildsToCart();
    //         setLoading(false)
    //         refreshData()
    //         toggleSidebar()
    //         let saved_builds = [];
    //         Cookies.set("saved_builds", saved_builds_parse, { expires: 7 });
    //         router.push("/")
    //     } else {
    //         try {
    //             for (var i = 0; i < selected_parse.length; i++) {
    //                 await addItem({
    //                     productId: btoa('gid://shopify/product/'+selected_parse[i].store_product_id),
    //                     variantId: btoa('gid://shopify/ProductVariant/'+selected_parse[i].store_variant_id),
    //                 })
    //             }
    
    //             const formdata = new FormData();
    //             formdata.append("token", configuration_token);
    //             formdata.append("selected_variants", JSON.stringify(selected_parse));
    //             const SUBMITSELECTEDPRODUCTSAPIURL = process.env.NEXT_PUBLIC_API_URL + "/submit-selected-products";
    //             const res = await fetch(SUBMITSELECTEDPRODUCTSAPIURL, {
    //                 method: "POST",
    //                 body: formdata,
    //             });
    //             const result = await res.json();
    //             if (result.status === true) {
    //                 Cookies.remove('build_token')
    //                 // router.push("../cart");
    //             }
    //             openSidebar()
    //             setLoading(false);
    //         } catch (err) {
    //           setLoading(false);
         
    //         }
    //     }
    // }
    const addToCart = async (conf_api_res) => {
        setLoading(true);
        let custom_attributes = [];
        const saved_builds = Cookies.get("saved_builds");
        let saved_builds_parse = [];
        if(saved_builds) {
            saved_builds_parse = JSON.parse(saved_builds)
        }
        saved_builds_parse.filter(item => item.build_token != conf_api_res?.build_token)
       let quantity = 1
        if(conf_api_res?.build_token) {
            const formdata = new FormData();
            formdata.append("enquiry_token", conf_api_res?.enquiry_token );
            formdata.append("build_token", conf_api_res?.build_token );
            formdata.append("build_quantity", quantity );
            formdata.append("is_build_added_cart", 1 );
            formdata.append("build_name", buildName );
            const STORECONFIGPCAPIURL = process.env.NEXT_PUBLIC_API_URL + "/store-configurator-pc-data";
            const res = await fetch(STORECONFIGPCAPIURL, {
            method: "POST",
            body: formdata,
            });
            let result;
            try {
                 result = await res.json();
                if (result.status === true) {
                    custom_attributes = [
                        {
                            key:"build_token",
                            value:result?.build_token ?? ""
                        },
                        {
                            key:"enquiry_token",
                            value:result?.enquiry_token ?? ""
                        },
                        {
                            key:"build_name",
                            value:buildName
                        },
                        {
                            key:"build_image",
                            value:result?.selected_variant_data[0].pimage ?? ""
                        },
                        {
                            key:"sub_total",
                            value:result?.sub_total.toString() ?? "0"
                        },
                    ]
                    await processBuildsToCart();
                    async function processBuildsToCart(){
                        for(let i = 0; i < conf_api_res.selected_variant_data.length; i++){
                            await make_api_call(conf_api_res.selected_variant_data[i]);
                        }
                    }
                    async function make_api_call(item){
                        console.log(item)
                        await addItemToCart2(item, custom_attributes);
                    }
                    setLoading(false)
                    refreshData()
                    toggleSidebar()
                    Cookies.remove("build_token");
                }

            } catch(error) {
                setLoading(false)
                refreshData()
                toast.error(error.toString(), {
                    position: "bottom-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            // Cookies.set("saved_builds", saved_builds_parse, { expires: 7 });
            Cookies.remove("saved_builds");
            router.push("/")
        } else {
            setLoading(false)
            toast.error("Something went wrong!! Please try to clear your cookies.", {
                position: "bottom-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }
    async function downloadBuild(val){
        const formdata = new FormData();
        formdata.append("enquiry_token", val.enquiry_token );
        formdata.append("build_token", val.build_token);
        // setLoading(true);
        const EXPORTBUILDAPIURL = process.env.NEXT_PUBLIC_API_URL + "/export-build-in-pdf";
        const res = await fetch(EXPORTBUILDAPIURL, {
            method: "POST",
            body: formdata,
        });
        
        const result = await res.json();
        toast.success("Download link is generated" , {
            position: "bottom-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
        if (result.status) {
            saveAs(
                result.pdf_url,
                result.pdf_name
            );
        }
    };
      const removeBuild = async(id) => {
          builds.splice(id, 1);
          toast.success("Build removed successfully", {
            position: "bottom-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
          Cookies.remove("saved_builds");
    }
    const handleNavigation = async() => {
        if(data && data?.phone) { 
          let findPhone = findPhoneNumbersInText(data.phone);
          const formdata = new FormData();
              formdata.append("first_name", data.firstName );
              formdata.append("last_name", data.lastName );
              formdata.append("email_id", data.email );
              formdata.append("phone_no", data.phone );
              if(findPhone.length>0) {
                const { country} = findPhone[0].number;
                let regionNames = new Intl.DisplayNames(['en'], {type: 'region'});
                let fullCountryName= regionNames.of(country); 
                formdata.append("country_iso", country );
                formdata.append("country", fullCountryName);
              }
              const ORDERPOSTAPIURL = process.env.NEXT_PUBLIC_API_URL + "/start-configuration";
              const res = await fetch(ORDERPOSTAPIURL, {
              method: "POST",
              body: formdata,
              });
              let result;
              try {
                result = await res.json() ;
                if (result.status === true) {
                    Cookies.set("configuration_token", result.token, { expires: 7 });
                    router.push("/gamingPCs/"+result.initial_step)
                } else {
                    router.push("/configurator");
                }
              } catch(error) {
                console.log("handleNavigation_error", error)
              }
        } else {
          // let accessValue = Cookies.get("configuration_token");
          // if(accessValue) {
          //   router.replace("/gamingPCs/processor");
          // } else {
          //   router.push("/configurator")
          // }
          router.push("/configurator")
        }
      };
      const {orders } = props;
      console.log("orders", orders)
    return(
        <div className={s.root}>
                {loading && <Loader />}
                <Wrapper>
            {
                orders.length > 0 ? (
                    orders.map((item,index) => {
                        const {node} = item;
                     
                        const {edges} = node.lineItems
                        return(
                            <Collapse
                            key={index}
                            title={node.name} 
                            date={node.processedAt} 
                            statusUrl={node.statusUrl} 
                            financialStatus={node.financialStatus} 
                            fulfillmentStatus={node.fulfillmentStatus} 
                            price={node.originalTotalPrice.amount}
                            >
                                <div className={s.expened}>                               
                                    <div className={s.reviewBuild}>
                                        <div className={s.selected_section}>
                                            <div className={s.selected_game}>
                                                <ul>
                                                {
                                                    node?.lineItems ? (
                                                        edges?.map((line, index2) => {
                                                            const {amount, currencyCode} = line.node.originalTotalPrice
                                                            return(
                                                                <li key={index2}>   
                                                                {
                                                                    line.node.variant && 
                                                                    <Image src={line.node.variant.image.originalSrc} alt="image" ></Image>
                                                                }                                    
                                                                    {/* <Image src={line.node.variant.image.originalSrc} alt="image" ></Image> */}
                                                                    <div className={s.content_flex}>
                                                                        <h5>{line.node.variant?.sku}</h5>
                                                                        <div className={s.des_content}>
                                                                            <p>{line.node.title}</p>
                                                                            <h4>{currencyCode} {amount}
                                                                            
                                                                            </h4>
                                                                            
                                                                        </div>
                                                                    </div> 
                                                                </li>
                                                            );
        
                                                        })
                                                    )
                                                    :
                                                    null
                                                    
                                                }                            
                                                </ul>
                                            </div>
                                            <div className={s.total}>
                                                <h3>Total</h3>
                                                <h3>AED {node.originalTotalPrice.amount}</h3>
                                            </div>  
                                            <div className="selected_section">
                                            {/* <div className="leftBottom">
                                                    <h2>Expected Assemble/Deliver Time</h2>
                                                    <p>Give Your Vektra Build A Name</p>
                                                    <div className="form-group customselect">
                                                        <input 
                                                        type="text" 
                                                        name="build_name" 
                                                        placeholder="Build Name"
                                                        value={buildName}
                                                        onChange={(e) => {
                                                            setBuildName(e.target.value)
                                                            if(e.target.value == "") {
                                                                setShowError(true)
                                                            } else {
                                                                setShowError(false)
                                                            }
                                                        }}
                                                        />
                                                        {showError && <span style={{color:"red",fontSize:"12px"}}>Build name is required.</span>}
                                                    </div>
                                            </div> */}
                                        </div> 
                                            {/* <div className={s.buttons}>
                                                
                                                <Button onClick={() => {
                                                     if(buildName) {
                                                        addToCart(node)
                                                     } else {
                                                        setShowError(true)
                                                     }
                                                   
                                                }}><span>Add to cart</span></Button>
                                                <Button onClick={() => downloadBuild(node)}><span>Download</span></Button>
                                                <Button2 className={s.backbtn} onClick={() => removeBuild(index)}>Remove</Button2>
                                            </div>                 */}
                                        </div>
                                    </div>
                                </div>
                            </Collapse>
                        );
                    } )
                )
                :
                (
                    <>
                    <div className={s.empty}>
                            {/* <HiOutlineLocationMarker className={s.icons}/> */}
                            <p>You have not added any build!</p>
                        </div>  
                    <div className={s.button}>    
                    <Button
                         onClick={() => handleNavigation()}
                        ><span>Configure New Build</span></Button>           
                        <Link href="/myaccount"><Button2>Back</Button2></Link>
                        
                    </div>
                        </>
                )
                
            }
           </Wrapper>
        </div>
    );
}

export default  Order;