import React, { useState } from 'react'
import Hero from './Herosection/Hero'
import Form from './Form/Form'
import Products from '@components/Homepage/TrandingPcs/Trading'
import Titlle from '@components/Configurator/Title/Title'
import Breadcrumbs from '@components/breadcrumbs/Breadcrumbs'
import { Spacing } from '@components/GlobalComponents/Spacing'

const config = ({ data }) => {
  const { hero_data } = data
  
  return (
    <React.Fragment>
      <Spacing>
        <Breadcrumbs breadcrumbs="Gaming PC Configurator" />
        <Hero />
        <Form />
        <Titlle />
        <Products data={hero_data} />
      </Spacing>
    </React.Fragment>
  )
}
export default config
