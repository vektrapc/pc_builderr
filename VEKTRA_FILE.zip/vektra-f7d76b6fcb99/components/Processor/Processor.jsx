import React from "react";
import HeroSection from "@components/PreConfigurator/Herosection/Hero";
import Filters from "@components/PreConfigurator/Filter/Filter";
import Product from "./Products/Products"

const Processor = () =>{
    return(
        <React.Fragment>
            <HeroSection />
            <Filters />
            <Product />
        </React.Fragment>
    );
}

export default Processor;