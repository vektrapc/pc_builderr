import React from 'react';
const  getFormattedPrice = (props) => {
    const price = new Intl.NumberFormat('en-UK', {  currency: 'GBP' }).format(props)
    return price
}

export default getFormattedPrice;
