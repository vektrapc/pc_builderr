import cn from 'classnames'
import React, { FC, ReactNode, useState } from 'react'
import s from './Collapse.module.css'
import { ChevronRight } from '@components/icons'
import { useSpring, a } from '@react-spring/web'
import useMeasure from 'react-use-measure'
import Image from "next/image"
import { useRouter } from 'next/router'
import moment from 'moment';
export interface CollapseProps {
  title: string
  isOpen: boolean
  images:string
  price:string
  date:string
  financialStatus:string
  statusUrl:string
  fulfillmentStatus:string
  children: ReactNode
}

const Collapse: FC<CollapseProps> = React.memo(({ title, isOpen, statusUrl, images, price, date, financialStatus,fulfillmentStatus, children }) => {
  const [isActive, setActive] = useState(isOpen? isOpen: false)
  const [ref, { height: viewHeight }] = useMeasure()
  const router = useRouter()
  const animProps = useSpring({
    height: isActive ? viewHeight : 0,
    config: { tension: 250, friction: 32, clamp: true, duration: 100 },
    opacity: isActive ? 1 : 0,
  })

  const toggle = () => setActive((x) => !x)
  console.log("router", router.pathname)
  return (
    <div
      className={s.root}
      
    >
      <div className={s.header} 
      role="button"
      tabIndex={0}
      aria-expanded={isActive}
      onClick={toggle}>
        <div className={s.panel}>
          {images && (
            <Image src={images} alt="image" width={70} height={70}></Image> 
          )}
          {
           router.pathname == "/orders" ? 
           <div className={s.neworderpanel}>
              <div className={s.orderdetsild}>
                <span className={s.label}>Order Id : <b><a href={statusUrl}>{title}</a></b></span>
                
                <span className={s.label}>Date : <b>{date? moment(date).format('MMMM Do YYYY'): Date.now()}</b></span>
                <span className={s.label}>Payment Status : <b >{financialStatus}</b></span>
                <span className={s.label}>Fulfillment Status : <b>{fulfillmentStatus}</b></span>
              </div>
            </div>
            :
          <div className={s.panelcontent}>
            <span className={s.label}>{title}</span>
            
            {
              price && (
                <h2>AED {price}</h2>
              )
            }
           
          </div>  
          }
         


        </div>
              <ChevronRight className={cn(s.icon, { [s.open]: isActive })} />
       
      </div>
      <a.div style={{ overflow: 'hidden', ...animProps }}>
        <div ref={ref} className={s.content}>
          {children}
        </div>
      </a.div>
    </div>
  )
})

export default Collapse
