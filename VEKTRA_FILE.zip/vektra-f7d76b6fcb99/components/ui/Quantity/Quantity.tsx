import React, { FC } from 'react'
import s from './Quantity.module.css'
import { Cross, Plus, Minus } from '@components/icons'
import cn from 'classnames'
import { RiDeleteBin7Line } from "react-icons/ri"

export interface QuantityProps {
  value: number
  increase: () => any
  decrease: () => any
  handleRemove: React.MouseEventHandler<HTMLButtonElement>
  handleChange: React.ChangeEventHandler<HTMLInputElement>
  max?: number
  hide: boolean
}

const Quantity: FC<QuantityProps> = ({
  value,
  increase,
  decrease,
  handleChange,
  handleRemove,
  hide,
  max = 6,
}) => {
  return (
    <div className="flex flex-row h-9 mt-2">
      <button className={s.delete} onClick={handleRemove}>
        <RiDeleteBin7Line width={20} height={20} />
      </button>
      <div className={s.quantity}>
        {
          !hide && 
<>
      <button
      type="button"
      onClick={decrease}
      className={s.actionsminus}
      style={{ marginLeft: '-1px' }}
      disabled={value <= 1}
    >
      <Minus width={18} height={18} />
    </button>
       
      
        <input
          className={s.input}
          onChange={(e) =>
            Number(e.target.value) < max + 1 ? handleChange(e) : () => {}
          }
          value={value}
          type="number"
          max={max}
      
          readOnly
        />
    
      
      <button
        type="button"
        onClick={increase}
        className={cn(s.actionsplus)}
        style={{ marginLeft: '-1px' }}
        disabled={value < 1 || value >= max}
      >
        <Plus width={18} height={18} />
      </button>
      </>
       }
      </div>
      
     
    </div>
  )
}

export default Quantity
