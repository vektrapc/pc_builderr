export { default } from './Marquee'
