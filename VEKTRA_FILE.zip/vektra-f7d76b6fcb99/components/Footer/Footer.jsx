import React from "react";
import Newsletter from "./Newsletter/Newsletter"
import FooterMenus from "./FooterMenu/FooterMenu"
import Loader from "@components/Loader/Loader";
import { useRouter } from 'next/router';
import { ToastContainer } from 'react-toastify';

import TrustPilotWidget from "../TrustPilotWidget"
const Footer = ({footerLinks}) => {

    const router = useRouter()
    const [loading, setLoading] = React.useState(null);
    const [timeoutId, setTimeoutId] = React.useState(null);
    const onRouteChangeStart = React.useCallback(() => {
    setLoading(true);
    }, []);
    const onRouteChangeDone = React.useCallback(() => {
      setLoading(false);
      setTimeoutId(
        setTimeout(() => {
          setTimeoutId(null);
          setLoading(null);
        }, 3000)
      );
    }, []);
    React.useEffect(() => {
      router.events.on('routeChangeStart', onRouteChangeStart);
      router.events.on('routeChangeComplete', onRouteChangeDone);
      router.events.on('routeChangeError', onRouteChangeDone);
  
      return () => {
        router.events.off('routeChangeStart', onRouteChangeStart);
        router.events.off('routeChangeComplete', onRouteChangeDone);
        router.events.off('routeChangeError', onRouteChangeDone);
      };
    }, [onRouteChangeDone, onRouteChangeStart, router.events]);
    React.useEffect(
      () => () => {
        if (timeoutId) clearTimeout(timeoutId);
      },
      [timeoutId]
    );
    return(
        <React.Fragment>
          <TrustPilotWidget />
     
          {/* <ToastContainer style={{fontSize:"18px"}} /> */}
            { loading && <Loader />}
           <Newsletter />
           <FooterMenus 
           footerLinks={footerLinks}
           />
        </React.Fragment>
    );
}
export default Footer;