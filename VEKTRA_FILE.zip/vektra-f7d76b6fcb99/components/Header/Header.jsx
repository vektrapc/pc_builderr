import React, { useState, useRef } from "react";
import { Wrapper } from "./Header.Style";
import { Container } from "../GlobalComponents/Container";
import { Row } from "../GlobalComponents/row";
import { Col_6 }  from "../GlobalComponents/Column";
import { Image } from "../GlobalComponents/Image";
import { MdSearch,MdKeyboardArrowDown, MdKeyboardArrowUp } from "react-icons/md";
import { BiUser,BiShoppingBag } from "react-icons/bi"
import  Menus  from "./Menus";
import Link from "next/link";
import { HiddenXS } from "../GlobalComponents/Desktop-visible"

 const Header = () => {
    const [click, setClick] = useState(false);
  const handleClick = () => setClick(!click);

     return(
         <React.Fragment>
            <HiddenXS>
                <Wrapper>
                        <div className="header">                        
                            <Container>
                                <div className="header_top_bar">
                                    <Row style={{ alignItems:"center",justifyContent:"space-between" }}>
                                        <Col_6>
                                            <div className="image_">
                                               <Link href="/home"><Image src="/images/logo.png"></Image></Link>
                                            </div>
                                        </Col_6>
                                        <Col_6>
                                            <div className="header_icons">
                                                <a style={{ borderRight:"1px solid #A9A9A9",padding:"0px 20px" }}><MdSearch className="icons" /></a>
                                                <a style={{ borderRight:"1px solid #A9A9A9",padding:"0px 20px" }} onClick={handleClick} className="userDrop"><BiUser className="icons" /> 
                                                {click ?  (<MdKeyboardArrowUp className="icons"/>) : (<MdKeyboardArrowDown className="icons"/>)}
                                                {click && (
                                                    <div className="dropdown" >
                                                        <ul>
                                                            <li><Link href="">Login</Link></li>
                                                            <li><Link href="">Register</Link></li>
                                                        </ul>
                                                    </div>
                                                ) 
                                                }                                                 
                                                </a>                                              
                                                <a style={{ paddingLeft:"20px",position: 'relative' }}><BiShoppingBag  className="icons"/><span className="count">0</span></a>                                          
                                            </div>
                                        </Col_6>
                                    </Row>
                                </div>                            
                            </Container>                                        
                        </div>
                        <Menus />
                </Wrapper> 
             </HiddenXS>
         </React.Fragment>
     );
 }

 export default Header;