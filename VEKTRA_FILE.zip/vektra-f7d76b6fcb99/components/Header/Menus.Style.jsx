import styled from "styled-components";
export const Wrapper = styled.div`
background:#262626;
.HeaderMenus {    
    padding: 0 15px;
    
    ul {
    display: flex;
    align-items: center;
    justify-content: space-between;
    li{
        position:relative;
        &::before{
            content: "";
            position: absolute;
            width: 100%;
            height: 0%;
            background: #0E0E0E;
            top: 0;
            left: 0;
            transition: 0.3s;
            }
        &:hover:before{
            height: 100%;
        }
        .dropdown{
            position: absolute;
            background: #0E0E0E;
            width: 100%;
            min-width: 200px;
            opacity: 0;
            visibility: hidden;
            
            transition: 0.3s;
                .dropdown-sub {
                    position: absolute;
                    width: 100%;
                    max-width: 500px;
                    left: 99%;
                    opacity: 0;
                    visibility: hidden;
                    margin-top: -44px;
                    transition: 0.3s;
                    background: #0E0E0E;
                    box-shadow: 1px 2px 3px #00000029;
                }
            }

            .dropdown ul {
            display: block !important;
            

            }
            svg.icons-2 {
                font-size: 24px;
                margin-left: 0;
                position: absolute;
                top: 11px;
                right: 0;
                width: 65px;
                
            }
            .dropdown ul li
            {
                &:hover .dropdown-sub {
                    opacity: 1;
                    visibility: visible;
                    }
                    a{
                padding: 10px 20px !important;
                text-align: left;
                text-transform: capitalize !important;
                color:#fff;
                &:hover{
                    color:#FFC53A;
                   
                }
               
            }
            } 
        &:hover {
            a{
                color:#F08601;
                
                
            }
            .dropdown{
                opacity: 1;
                    visibility: visible; 
                }
                .icons{
                transform:rotate(180deg);
                color:#F08600;
                }
        } 
        a {
            color: #FCFCFC;
            font-size: 16px;
            text-transform: uppercase;
            padding: 15px 35px;
            display: block;
            position: relative;
            transition: 0.3s;
            box-shadow: unset;
            outline: none;
            border: 0;
            display: flex;
            align-items: center;
        }
            .icons{
                font-size: 19px;
                margin-left: 0;
                position: absolute;
                top: 36%;
                right: 0;
               
            }
        }
    }
}



}
@media only screen and (max-width:900px) {
    .HeaderMenus {    
  
  background: #262626;
    position: fixed;
    width: 40%;
    left: 0;
    top: 57px;
    height: 100%;
    z-index:9999;

    ul {
        display: block;
        li {
            &::before{
                display:none;
            }
            a{
                text-align:left;
                &:hover{
                    background: transparent;
                    color: #FFC53A;
                }
            }
        }
    }
}
@media only screen and (max-width:767px) {
    .dropdown {
            position: relative !important;
            background: #0E0E0E;
            width: 100%;
            min-width: 200px;
            opacity: 1 !important;
            visibility: visible !important;
            -webkit-transition: 0.3s;
            transition: 0.3s;
            display: none;
        }
        .dropdown-sub {
            position: relative !important;
            background: #0E0E0E;
            width: 100%;
            min-width: 200px;
            opacity: 1 !important;
            visibility: visible !important;
            -webkit-transition: 0.3s;
            transition: 0.3s;
            display: none;
            left: 0 !important;
            margin-top: 0 !important;
            background: #262626 !important;
        }
    .HeaderMenus {    
  
  background: #262626;
    position: fixed;
    width: 100%;
    left: 0;
    top: 55px;
    height: 92vh;
    padding: 0;
    overflow: auto;
    padding-bottom: 40px;

  

    ul {
        
        .open{
            display:block;
        }
        display: block;

        a {
           color:#fff !important;
            padding:15px 22px !important;
        }
        
      li .icons {
        transform: unset !important;
        
                font-size: 24px;
                margin-left: 0;
                position: absolute;
                top: 15px;
                right: 0;
                width: 63px;
            }
            li  .rotate{
            transform:rotate(180deg) !important;
        }

    }
      svg.icons-2 {
               
                transform: rotate(90deg);
            }
            svg.icons-2.rotted {
    transform: rotate(-90deg) !important;
}
    
}
`;
