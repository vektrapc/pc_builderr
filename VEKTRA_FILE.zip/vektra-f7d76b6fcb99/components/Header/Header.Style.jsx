import styled from "styled-components";

export const Wrapper = styled.div`
.header{
    background: #0E0E0E;
    padding: 10px 0;
}
    
.icons{
    color:#fff;
    font-size: 25px;
}
.header_icons {
    text-align: right;
    display: flex;
    align-items: center;
    justify-content: flex-end;
}
.count {
    position: absolute;
    background: #FFC53A;
    right: -13px;
    top: 4px;
    width: 20px;
    display: flex;
    height: 20px;
    border-radius: 50px;
    align-items: center;
    justify-content: center;
    font-size: 12px;
}
.userDrop{
    display: flex;
    color: #fff;
    align-items: center;
    position: relative;
}

.dropdown {
    position: absolute;
    top: 40px;
    text-align: left;
    background: #FFC53A;
    padding: 0;
    min-width: 150px;
    right: 0;
    z-index: 9;
    padding: 5px 0;
    &::before{
        content: "";
        width: 15px;
        height: 15px;
        background: #FFC53A;
        position: absolute;
        top: -8px;
        right: 30px;
        transform: rotate(
    45deg
    );
    }
    ul{
        li{
            a{
                color: #0E0E0E;
                padding: 3px 15px;
                display: block;
                border-bottom: 1px;
                font-family: "RFlexBold";
                text-transform: uppercase;
            }
        }
    }
    }
    
}


`;
