import React,{ useState, useEffect }  from "react"
import { Wrapper } from "./HeaderResponsive.Style"
import { Image } from "./../GlobalComponents/Image"
import { MdMenu,MdClose,MdSearch } from "react-icons/md"
import { MdKeyboardArrowDown, MdKeyboardArrowUp } from "react-icons/md";
import { BiUser,BiShoppingBag } from "react-icons/bi"
import Link from "next/link";
import { VisibleXS } from "../GlobalComponents/Mobile-visible";


const MobileHeader = () => {
    const [click, setClick] = useState(false);
    const [click2, setClick2] = useState(false);
         const handleClick = (e) => {setClick(!click);};
        
      const closemenu = () => {setClick2(!click2)}
      
    return(
        <React.Fragment>
        <VisibleXS>
            <Wrapper >
                <div className="mobile_header">
                       
                        <div className="navbar">
                            <a onClick={closemenu}>
                            {click2 ? (<MdClose className="icons" style={{fontSize: "35px" }}/>):(<MdMenu  className="icons" style={{fontSize: "35px" }}/>)}
                            </a>
                            <Image src="/images/logo.png"></Image>
                        </div>                   
                        <div className="nav-menu">
                            <a style={{ borderRight:"1px solid #A9A9A9" }} onClick={handleClick} className="userDrop"><BiUser className="icons" /> 
                            {click ?  (<MdKeyboardArrowUp className="icons"/>) : (<MdKeyboardArrowDown className="icons"/>)}
                                {click && (
                                <div className="dropdown" >
                                    <ul>
                                        <li><Link href="">Login</Link></li>
                                        <li><Link href="">Register</Link></li>
                                    </ul>
                                </div>
                                ) 
                                }                                                 
                            </a>  
                            <a style={{paddingRight: "0"}}><BiShoppingBag  className="icons"/><span className="count">0</span></a>
                        </div>
                        <div className={click2 ? ("Navbar-nav-menu open"):('Navbar-nav-menu') }>
                            <div className="search_bar">
                                <form>
                                    <input type="text" placeholder="Search..."/>
                                    <button><MdSearch  className="icons"/></button>
                                </form>
                            </div>
                            <ul>
                                <li onClick={closemenu}><Link href=""><a>Home</a></Link></li>
                                <li onClick={closemenu}><Link href=""><a>Per-configured PCs</a></Link></li>
                                <li onClick={closemenu}><Link href=""><a>PC Parts</a></Link></li>
                                <li onClick={closemenu}><Link href=""><a>Accessories</a></Link></li>
                                <li onClick={closemenu}><Link href=""><a>Support</a></Link></li>
                                <li onClick={closemenu}><Link href=""><a style={{color:"#F08601"}}>Sale</a></Link></li>
                            </ul>
                        </div>
                        
                </div>             
                </Wrapper>
                <div style={{height:"60px"}} className="mobilespace"></div>
            </VisibleXS>
        </React.Fragment>
    );
}
export default MobileHeader;