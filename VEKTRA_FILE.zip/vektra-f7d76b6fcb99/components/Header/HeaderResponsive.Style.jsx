import styled from "styled-components"
export const Wrapper = styled.div`

background:#0E0E0E;
padding:5px 10px;
position: fixed;
    width: 100%;
    top: 0;
    z-index:99;
.mobile_header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.navbar {
    display: flex;
    align-items: center;
    
}
.icons {
        color: #fff;
        font-size: 28px;
    }
.navbar img {
    width: 100px;
    margin-left: 10px;
}
.nav-menu{  
    padding: 0 10px;
    display: flex;
    align-items: center;
    a {
        padding: 0 10px;
        display: flex;
        align-items: center;
        position: relative;
    }

} 
.dropdown {
    position: absolute;
    top: 37px;
    text-align: left;
    background: #FFC53A;
    padding: 0;
    min-width: 150px;
    right: -13px;
    z-index: 999;
    padding: 5px 0;

    &::before{
        content: "";
        width: 15px;
        height: 15px;
        background: #FFC53A;
        position: absolute;
        top: -8px;
        right: 30px;
        transform: rotate(
    45deg
    );
    }
    ul{
        li{
            a{
                color: #0E0E0E;
                padding: 3px 15px;
                display: block;
                border-bottom: 1px;
                font-family: "RFlexBold";
                text-transform: uppercase;
            }
        }
    }
    }
    
}

.Navbar-nav-menu {
    position: fixed;
    width: 100%;
    background: #262626;
    left: -100%;
    top: 55px;
    height: 100%;
    z-index: 9;
    padding: 12px 15px;
    transition: 0.5s;
   ul{
        li {
            font-size: 16px;
            padding: 8px 0;
            text-transform: uppercase;
            color: #fff;
        }
   }
}
.open {
    left: 0 !important;
}

.search_bar {
    form {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
    border-bottom: 1px solid #fff;
        input {
            width: 100%;
            background: transparent;
            outline: none !important;
            padding: 10px 0;
            color: #fff;
            font-size: 14px;
            &::placeholder{
                color:#fff;
            }
        }
        .icons{
            color: #ffffff;
            font-size: 30px;
        }
    }
}
.count {
    position: absolute;
    background: #FFC53A;
    right: -13px;
    top: 4px;
    width: 20px;
    display: flex;
    height: 20px;
    border-radius: 50px;
    align-items: center;
    justify-content: center;
    font-size: 12px;
}



`;