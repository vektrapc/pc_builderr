import React from "react";
import { Wrapper } from "./Menus.Style";
import { Container } from "../GlobalComponents/Container";
import Link from "next/link";

 const Menus = () => {
     return(
         <React.Fragment>
             <Wrapper>                    
                    <div className="NavMenus">
                        <Container>
                            <div className="HeaderMenus">
                                <ul>
                                    <li><Link href="/home">Home</Link></li>
                                    <li><Link href="/pre-configurator">Per-configured PCs</Link></li>
                                    <li><Link href="">PC Parts</Link></li>
                                    <li><Link href="">Accessories</Link></li>
                                    <li><Link href="">Support</Link></li>
                                    <li><Link href=""><a style={{color:"#F08601"}}>Sale</a></Link></li>
                                </ul>

                            </div>
                        </Container>
                    </div>
             </Wrapper>
         </React.Fragment>
     );
 }

 export default Menus;