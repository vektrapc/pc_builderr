import React from "react";
import { Wrapper } from "./Loader.style";
import Image from 'next/image';

const Loader = (props) => {
    return(
        <React.Fragment>
            <Wrapper>
                <div className="loader-overlay">
                    <div className="loaderimage">
                    <Image src="/images/loader.gif" alt="image" layout="fill" objectFit="contain"></Image>
                    </div>
                </div>
            </Wrapper>
        </React.Fragment>
    );
}
export default Loader;