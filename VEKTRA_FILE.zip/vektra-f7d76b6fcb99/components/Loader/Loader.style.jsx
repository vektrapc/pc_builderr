import styled from "styled-components"

export const Wrapper = styled.div`
.loader-overlay {
  position: fixed;
  display: block;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgb(0 0 0 / 50%);
  backdrop-filter: blur(1px);
  z-index: 2;
  cursor: pointer;
}
.loader-overlay img{

}
.loaderimage{
    width: 100px;
    height: 100%;
    position: relative;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
}

`;