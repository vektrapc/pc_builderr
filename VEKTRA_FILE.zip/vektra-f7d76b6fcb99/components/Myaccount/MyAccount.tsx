import Breadcrumbs from "@components/breadcrumbs/Breadcrumbs";
import { Col_4 } from "@components/GlobalComponents/Column";
import { Container } from "@components/GlobalComponents/Container";
import { Heading1 } from "@components/GlobalComponents/Heading";
import { Row } from "@components/GlobalComponents/row";
import { Spacing } from "@components/GlobalComponents/Spacing";
import Link from "next/link";
import React,{ FC } from "react";
import s from "./MyAccount.module.css"
import { IoMdCheckboxOutline } from "react-icons/io"
import { BsListCheck } from "react-icons/bs"
import { FiShoppingCart } from "react-icons/fi"
import { BiPowerOff,BiUser } from "react-icons/bi"
import { RiUserLocationLine } from "react-icons/ri"
import useLogout from '@framework/auth/use-logout'


interface Props {
   
  }
const items = [
    {
        icons:<BiUser className={s.icons}/>,
        name:"My Profile",
        url:"/profile"
    },
    {
        icons:<BsListCheck  className={s.icons}/>,
        name:"My Orders",
        url:"/orders"
    },
    {
        icons:<FiShoppingCart  className={s.icons}/>,
        name:"My Cart",
        url:"/cart"
    },
    {
        icons:<IoMdCheckboxOutline  className={s.icons}/>,
        name:"Saved Build",
        url:"/saved-build"
    },
    {
        icons:<BiPowerOff  className={s.icons}/>,
        name:"Logout",
        url:""
    },
    // {
    //     icons:<RiUserLocationLine  className={s.icons}/>,
    //     name:"Address Book",
    //     url:"/address"
    // },
   
]
const MyAccount: FC<Props> = () => {
    const logout = useLogout()
    return(
        <>
            <div className={s.root}>
                <Spacing>
                <Breadcrumbs  breadcrumbs="My Account"/>
                    <Container>                       
                        <Heading1>My Account</Heading1>
                        <div className={s.account}>
                            <Row style={{ justifyContent:"flex-start" }}>
                                {
                                    items.map((post,index) => {
                                        return(
                                        <Col_4 key={index} className={s.mobile}>
                                            { (post.name == "Logout") ?
                                                <a onClick={() => logout()}>
                                                    <div className={s.Card} >
                                                        <span>{post.icons}</span>
                                                        <h2>{post.name}</h2>
                                                    </div>
                                                </a>
                                                :
                                                <Link href={post.url}>
                                                    <a>
                                                        <div className={s.Card} >
                                                            <span>{post.icons}</span>
                                                            <h2>{post.name}</h2>
                                                        </div>
                                                    </a>
                                                </Link> 

                                            }                                     
                                        </Col_4>
                                        );
                                    })
                                }
                            </Row>
                        </div>
                    </Container>
                </Spacing>
            </div>
        </>
    )
}

export default MyAccount;