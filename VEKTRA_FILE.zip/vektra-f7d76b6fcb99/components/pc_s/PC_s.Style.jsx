import styled from "styled-components";

export const Wrapper = styled.div`
padding:0px 0 25px;
h1{
  
    font-size: 40px;
    color: #fff;
    margin-bottom: 30px;
    line-height: 45px;

}


`;