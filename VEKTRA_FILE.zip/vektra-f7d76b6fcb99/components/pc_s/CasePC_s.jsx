import React from "react";
import { Wrapper } from "./PC_s.Style";
import { Container } from "@components/GlobalComponents/Container";
import Case from "./pcs_process/case/Case"

const Pcs = ({slug,conf_api_res}) =>{
    return(
        <React.Fragment>
            <Wrapper>
                <Container>
                    <h1>Gaming PCs built for you </h1> 
                    <Case slug={slug} conf_api_res={conf_api_res}/>                   
                </Container>
            </Wrapper>
        </React.Fragment>
    );
}
export default Pcs;