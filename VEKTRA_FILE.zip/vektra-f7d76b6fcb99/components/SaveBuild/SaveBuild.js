import React, { FC,useState } from "react"
import s from "./SaveBuild.module.css"
import Collapse from "../ui/Collapse"
import { Image } from "../GlobalComponents/Image"
import { Button, Button2 } from "../GlobalComponents/Button"
import Cookies from 'js-cookie';
import { useRouter } from 'next/router';
import  { Wrapper } from "./Saved.Style"
import Loader from "../Loader/Loader";
import { useAddItem } from '@framework/cart'
import {Text, Rating, useUI } from '@components/ui';
import Link from "next/link";
import useCustomer from '@framework/customer/use-customer'
import { findPhoneNumbersInText } from 'libphonenumber-js'
import { toast } from 'react-toastify';
const  item = [
    {
        name:"Corsair 4000D Airflow",
        image:"/images/case.png",
        price:"450.00"
    },
    {
        name:"Corsair 3000D Airflow",
        image:"/images/case.png",
        price:"450.00"
    }
]
const items = [
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
    {
        image:"/images/logoprodu.png",
        title:"Case",
        desc:"Corsair 3000D AirFlow Black",
        price:"539"
    },  
]

const SaveBuild = (props) => {
    const [loading, setLoading] = useState(false)
    const router = useRouter();
    const addItem = useAddItem();
    const [buildName, setBuildName] = useState("");
    const { data } = useCustomer()
    const [showError, setShowError] = useState(false);
    const { toggleSidebar, closeSidebarIfPresent, openModal, addBuildToCart} = useUI()
    // const builds = props.builds;
    const [builds, setBuilds] = useState(props.builds);
    const refreshData = () => {
        router.replace(router.asPath);
    }
    const addItemToCart = async(values) => {
        await addItem({
          productId: btoa('gid://shopify/Product/'+values.store_product_id),
          variantId: btoa('gid://shopify/ProductVariant/'+values.store_variant_id),
        })
      }
      const addItemToCart2 = async(values, attr) => {
        await addItem({
          productId: btoa('gid://shopify/Product/'+values.store_product_id),
          variantId: btoa('gid://shopify/ProductVariant/'+values.store_variant_id),
          customAttributes: attr,
        })
    }
    const addToCart = async (conf_api_res) => {
        setLoading(true);
        let custom_attributes = [];
        const saved_builds = Cookies.get("saved_builds");
        let saved_builds_parse = [];
        if(saved_builds) {
            saved_builds_parse = JSON.parse(saved_builds)
        }
        saved_builds_parse.filter(item => item.build_token != conf_api_res?.build_token)
       let quantity = 1
        if(conf_api_res?.build_token) {
            const formdata = new FormData();
            formdata.append("enquiry_token", conf_api_res?.enquiry_token );
            formdata.append("build_token", conf_api_res?.build_token );
            formdata.append("build_quantity", quantity );
            formdata.append("is_build_added_cart", 1 );
            formdata.append("build_name", buildName );
            const STORECONFIGPCAPIURL = process.env.NEXT_PUBLIC_API_URL + "/store-configurator-pc-data";
            const res = await fetch(STORECONFIGPCAPIURL, {
            method: "POST",
            body: formdata,
            });
            let result;
            try {
                 result = await res.json();
                if (result.status === true) {
                    custom_attributes = [
                        {
                            key:"_build_token",
                            value:result?.build_token ?? ""
                        },
                        {
                            key:"_enquiry_token",
                            value:result?.enquiry_token ?? ""
                        },
                        {
                            key:"_build_name",
                            value:buildName
                        },
                        {
                            key:"_build_image",
                            value:result?.selected_variant_data[0].pimage ?? ""
                        },
                        {
                            key:"_sub_total",
                            value:result?.sub_total.toString() ?? "0"
                        },
                    ]
                    await processBuildsToCart();
                    async function processBuildsToCart(){
                        for(let i = 0; i < conf_api_res.selected_variant_data.length; i++){
                            await make_api_call(conf_api_res.selected_variant_data[i]);
                        }
                    }
                    async function make_api_call(item){

                        await addItemToCart2(item, custom_attributes);
                    }
                    setLoading(false)
                    refreshData()
                    toggleSidebar()
                    Cookies.remove("build_token");
                }

            } catch(error) {
                setLoading(false)
                refreshData()
                toast.error(error.toString(), {
                    position: "bottom-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            // Cookies.set("saved_builds", saved_builds_parse, { expires: 7 });
            Cookies.remove("saved_builds");
            router.push("/")
        } else {
            setLoading(false)
            toast.error("Something went wrong!! Please try to clear your cookies.", {
                position: "bottom-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }
    async function downloadBuild(val){
        const formdata = new FormData();
        formdata.append("enquiry_token", val.enquiry_token );
        formdata.append("build_token", val.build_token);
        // setLoading(true);
        const EXPORTBUILDAPIURL = process.env.NEXT_PUBLIC_API_URL + "/export-build-in-pdf";
        const res = await fetch(EXPORTBUILDAPIURL, {
            method: "POST",
            body: formdata,
        });
        
        const result = await res.json();
        toast.success("Download link is generated" , {
            position: "bottom-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
        if (result.status) {
            saveAs(
                result.pdf_url,
                result.pdf_name
            );
        }
    };
      const removeBuild = async(id) => {
          console.log("builds", id)
          builds.splice(id, 1);
          setBuilds(builds)
          console.log("buildss", builds)
          Cookies.set("saved_builds", builds, { expires: 7 });
          toast.success("Build removed successfully", {
            position: "bottom-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }
    const handleNavigation = async() => {
        if(data && data?.phone) { 
          let findPhone = findPhoneNumbersInText(data.phone);
          const formdata = new FormData();
              formdata.append("first_name", data.firstName );
              formdata.append("last_name", data.lastName );
              formdata.append("email_id", data.email );
              formdata.append("phone_no", data.phone );
              if(findPhone.length>0) {
                const { country} = findPhone[0].number;
                let regionNames = new Intl.DisplayNames(['en'], {type: 'region'});
                let fullCountryName= regionNames.of(country); 
                formdata.append("country_iso", country );
                formdata.append("country", fullCountryName);
              }
              const ORDERPOSTAPIURL = process.env.NEXT_PUBLIC_API_URL + "/start-configuration";
              const res = await fetch(ORDERPOSTAPIURL, {
              method: "POST",
              body: formdata,
              });
              let result;
              try {
                result = await res.json() ;
                if (result.status === true) {
                    Cookies.set("configuration_token", result.token, { expires: 7 });
                    router.push("/gamingPCs/"+result.initial_step)
                } else {
                    router.push("/configurator");
                }
              } catch(error) {
                console.log("handleNavigation_error", error)
              }
        } else {
          // let accessValue = Cookies.get("configuration_token");
          // if(accessValue) {
          //   router.replace("/gamingPCs/processor");
          // } else {
          //   router.push("/configurator")
          // }
          router.push("/configurator")
        }
      };
    return(
        <div className={s.root}>
                {loading && <Loader />}
                <Wrapper>
            {
                builds.length > 0 ? (
                    builds.map((post,index) => {
                       return(
                            <Collapse
                            key={index}
                            title={post?.build_name} 
                            images={"/images/case.png"} 
                            price={post.sub_total}>
                                <div className={s.expened}>                               
                                    <div className={s.reviewBuild}>
                                        <div className={s.selected_section}>
                                          
                                            <div className={s.selected_game}>
                                                <ul>
                                                {
                                                    post?.selected_variant_data?.map((item, index2) => {
                                                        return(
                                                            <li key={index2}>                                       
                                                                <Image src={item.pimage} alt="image" ></Image>
                                                                <div className={s.content_flex}>
                                                                    <h5>{item.product_type}</h5>
                                                                    <div className={s.des_content}>
                                                                        <p>{item.ptitle}</p>
                                                                        <h4>AED {item.price}
                                                                        
                                                                        </h4>
                                                                        
                                                                    </div>
                                                                </div> 
                                                            </li>
                                                        );
    
                                                    })
                                                }                            
                                                </ul>
                                            </div>
                                            <div className={s.total}>
                                                <h3>Total</h3>
                                                <h3>AED {post.sub_total}</h3>
                                                
                                            </div>  
                                            {/* <div className="selected_section">
                                                <div className="leftBottom">
                                                  
                                                    <p>Give Your Vektra Build A Name</p>
                                                    <div className="form-group customselect">
                                                        <input 
                                                        type="text" 
                                                        name="build_name" 
                                                        placeholder="Build Name"
                                                        value={buildName}
                                                        onChange={(e) => {
                                                            setBuildName(e.target.value)
                                                            if(e.target.value == "") {
                                                                setShowError(true)
                                                            } else {
                                                                setShowError(false)
                                                            }
                                                        }}
                                                        />
                                                        {showError && <span style={{color:"red",fontSize:"12px"}}>Build name is required.</span>}
                                                    </div>
                                                </div>
                                            </div>  */}
                                            <div className={s.buttons}>
                                                
                                                <Button onClick={() => {
                                                     if(post?.build_name) {
                                                        addToCart(post)
                                                     } else {
                                                        setShowError(true)
                                                     }
                                                   
                                                }}><span>Add to cart</span></Button>
                                                <Button onClick={() => downloadBuild(post)}><span>Download</span></Button>
                                                <Button2 className={s.backbtn} onClick={() => removeBuild(index)}>Remove</Button2>
                                            </div>                
                                        </div>
                                    </div>
                                </div>
                            </Collapse>
                        );
                    } )
                )
                :
                (
                    <>
                    <div className={s.empty}>
                            {/* <HiOutlineLocationMarker className={s.icons}/> */}
                            <p>You have not added any build!</p>
                        </div>  
                    <div className={s.button}>    
                    <Button
                         onClick={() => handleNavigation()}
                        ><span>Configure New Build</span></Button>           
                        <Link href="/myaccount"><Button2>Back</Button2></Link>
                        
                    </div>
                        </>
                )
                
            }
           </Wrapper>
        </div>
    );
}

export default  SaveBuild;