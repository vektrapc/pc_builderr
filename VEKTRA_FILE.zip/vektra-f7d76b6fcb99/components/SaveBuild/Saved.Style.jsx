import styled from "styled-components"

export const Wrapper = styled.div`


.selected_game {
    ul {
        li {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
            justify-content: space-between;
            img{
                width: 50px;
                margin-right: 10px;
            }
            
        }
    }
}
.content_flex {
    color: #fff;
    width: 90%;
}
.des_content {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    h4 {
        display: flex;
        align-items: center;
    width: 35%;
    justify-content: right;
    }
}
.editicons {
    margin-left: 20px;
   color:#fff;
    font-size: 25px;    
    cursor: pointer;
    &:hover{
        color: #FFC53A;
    }

}
.total {
    display: flex;
    justify-content: space-between;
    border-top: 1px solid #979797;
    margin-right: 0;
    padding: 10px 0;
    padding-right: 45px;
    h3{
        font-size: 25px;
        color: #fff;
    }
}

.leftBottom {
    h2 {
        margin-bottom: 0;
        text-align:left;
    }
    h3{
        font-size: 25px;
    color: #fff;
    }
}


    .reviewBuild {
    width: 100%;
    max-width: 600px;
    margin: 0 auto;
}

.buttons {
    text-align: center;
    padding: 20px 0;
    button {
        margin: 0 10px;
        width: 39%;
    }
    .backbtn {
      
    }
}
.toptitle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #979797;
    padding-bottom:15px;
}

.action span {
    margin-left: 15px;
    border: 0 !important;
    padding: 0 0;
    position: relative;

}


.action {
    display: flex;
    align-items: center;
    
    
}
.action .icons{
    color: #B7B7B7 !important;
    font-size: 25px;

}

.tooltip {
    font-size: 12px;
    position: absolute;
    top: -24px;
    background: #4a4a4a;
    padding: 3px 10px;
    border-radius: 2px;
    left: -10px;
    opacity: 0;
    visibility: hidden;
    transition: 0.5s;
}

.action span:hover .tooltip{
    opacity: 1;
    visibility: visible;
}
.form-group {
    margin-bottom: 20px;
        input , select {
            border-bottom: 2px solid #525252;
            width: 100%;
            max-width: 100%;
            margin-bottom: 0;
            text-align: left;
            background: transparent;
            font-size: 18px;
            padding: 10px 0;
            font-family: "RFlexRegular";
            color:#fff;
            outline:none;
            &:focus{
                border-color:#7F4A07;
            }
            &::placeholder{
                color:#f2f2f2;
            }
           
        }
    }
@media only screen and (max-width: 767px) {
    .des_content {
        align-items: flex-start;
        p {
            width: 50%;
        }
    }
    .total {
        padding-right: 0;
    }
    .buttons {
    padding-bottom: 0;
     button {
        margin: 15px 0 0px;
        width: 80%;
    }
}
}
`;