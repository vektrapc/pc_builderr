import { useCallback } from 'react'
import type { MutationHook } from '../../commerce/utils/types'
import { CommerceError } from '../../commerce/utils/errors'
import useRecover, { UseRecover } from '../../commerce/auth/use-recover'
import type { RecoverHook } from '../types/recover'
import useCustomer from '../customer/use-customer'

export default useRecover as UseRecover<typeof handler>

export const handler: MutationHook<RecoverHook> = {
  fetchOptions: {
    url: '/api/recover',
    method: 'POST',
  },
  async fetcher({ input: { email }, options, fetch }) {
    if (!(email)) {
      throw new CommerceError({
        message:
          'A first name, last name, email an are required to login',
      })
    }

    return fetch({
      ...options,
      body: { email },
    })
  },
  useHook: ({ fetch }) => () => {
    const { revalidate } = useCustomer()

    return useCallback(
      async function login(input) {
        const data = await fetch({ input })
        await revalidate()
        return data
      },
      [fetch, revalidate]
    )
  },
}
