import * as Core from '../../commerce/types/recover'
import type { RecoverMutationVariables } from '../schema'

export * from '../../commerce/types/login'

export type RecoverOperation = Core.RecoverOperation & {
  variables: RecoverMutationVariables
}
