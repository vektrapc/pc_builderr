import * as Core from '../../commerce/types/address'
import type { AddressCreateInput } from '../schema'
export * from '../../commerce/types/address'
export type AddressOperation = Core.AddressOperation & {
    variables: AddressCreateInput
}
