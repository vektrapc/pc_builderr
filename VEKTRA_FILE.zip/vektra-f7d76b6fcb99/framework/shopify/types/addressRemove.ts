import * as Core from '../../commerce/types/addressRemove'
import type { AddressDeleteInput } from '../schema'
export * from '../../commerce/types/addressRemove'
export type AddressRemoveOperation = Core.AddressRemoveSchema & {
    variables: AddressDeleteInput
}
