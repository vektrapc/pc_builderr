import * as Core from '../../commerce/types/recover'
import type { CustomerRecoverCreateInput } from '../schema'

export * from '../../commerce/types/recover'

export type RecoverOperation = Core.RecoverOperation & {
  variables: CustomerRecoverCreateInput
}
