import { useCallback } from 'react'
import type { MutationHook } from '../../commerce/utils/types'
import { CommerceError } from '../../commerce/utils/errors'
import useRecover, { UseRecover } from '../../commerce/auth/use-recover'
import type { RecoverHook } from '../types/recover'
import useCustomer from '../customer/use-customer'
import { useRouter } from 'next/router';
import { ToastContainer, toast } from 'react-toastify';
import {
  setCustomerToken,
  throwUserErrors,
  customerRecoverMutation
} from '../utils'
import { Mutation, MutationCustomerRecoverArgs } from '../schema'

export default useRecover as UseRecover<typeof handler>

export const handler: MutationHook<RecoverHook> = {
  fetchOptions: {
    query: customerRecoverMutation,
  },
  async fetcher({ input: {email}, options, fetch }) {
    if (!email) {
      throw new CommerceError({
        message:
          'Email is required to recover account',
      })
    }

    const { customerRecover } = await fetch<
      Mutation,
      MutationCustomerRecoverArgs
    >({
      ...options,
      variables: {
        email: email,
      },
    })

    if(customerRecover?.customerUserErrors?.length == 0) {
        toast.success('Password reset link sent successfully', {
        position: "bottom-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        });
        // throwUserErrors(customerRecover?.customerUserErrors)
    }
    // toast.success('Password reset successfully', {
    //   position: "bottom-right",
    //   autoClose: 5000,
    //   hideProgressBar: false,
    //   closeOnClick: true,
    //   pauseOnHover: true,
    //   draggable: true,
    //   progress: undefined,
    //   });
    throwUserErrors(customerRecover?.customerUserErrors)
    return null
  },
  useHook: ({ fetch }) => () => {
    const router = useRouter()
    const { revalidate } = useCustomer()

    return useCallback(
      async function login(input) {
        const data = await fetch({ input })
        await revalidate()
        router.push("/myaccount");
        return data
      },
      [fetch, revalidate]
    )
  },
}
