import getSortVariables from './get-sort-variables'
import { SearchProductsBody } from '../types/product'

export const getSearchVariables = ({
  brandId,
  search,
  categoryId,
  sort,
  locale,
  first,
  last,
  before,
  after,
}: SearchProductsBody) => {
  // let query = 'ON SALE'//
  let query = ''

  if (search) {
    // query += `product_type:${search} OR title:${search} OR tag:${search} `
    query += `title:${search}`
  }

  if (brandId) {
    query += `${search ? 'AND ' : ''}vendor:${brandId}`
  }

  return {
    categoryId,
    first,
    last,
    before,
    after,
    query,
    ...getSortVariables(sort, !!categoryId),
    ...(locale && {
      locale,
    }),
  }
}

export default getSearchVariables
