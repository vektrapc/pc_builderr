import { useCallback } from 'react';
import type { MutationHook } from '../../commerce/utils/types'
import { CommerceError } from '../../commerce/utils/errors'
import useCustomer, { UseCustomer } from "../../commerce/customer/use-customer"
import useAddress, { UseAddress } from "../../commerce/customer/use-address"
import type { AddressHook } from '../types/address'
import { addressCreateMutation, getCustomerToken,throwUserErrors } from '../utils'
import { Mutation, MutationAddressCreateArgs } from '../schema'
import { useRouter } from 'next/router';
import { ToastContainer, toast } from 'react-toastify';
export default useAddress as UseAddress<typeof handler>

export const handler: MutationHook<AddressHook> = {
  fetchOptions: {
    query: addressCreateMutation,
  },
  async fetcher({ 
    input: { 
      address1, 
      address2, 
      city, 
      company, 
      country, 
      firstName, 
      lastName, 
      phone, 
      province,
      zip
    },
    options, 
    fetch ,
  }) {
    if(!address1) {
      throw new CommerceError({
        message:
          'Address1 is required to recover account',
      })
    }
    const customerAccessToken = getCustomerToken()
    let customerAddress:any
    let customerUserErrors:any
    if (customerAccessToken) {
      const { customerAddressCreate } = await fetch<Mutation, MutationAddressCreateArgs>({
        ...options,
        variables: { 
          address: {
            address1,
            address2,
            city,
            company,
            country,
            firstName,
            lastName,
            phone,
            province,
            zip:zip,
          },
          customerAccessToken: getCustomerToken() },
      }) 
      customerAddress = customerAddressCreate?.customerUserErrors
      customerUserErrors = customerAddressCreate?.customerUserErrors
       
      if(customerAddressCreate?.customerUserErrors.length == 0) {
        toast.success('Address Added Successfully', {
          position: "bottom-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          });
      }
      return customerAddressCreate
    }
    throwUserErrors(customerUserErrors)
    return customerAddress
  },
  useHook: ({ fetch }) => () => {
    const router = useRouter()
    const { revalidate } = useCustomer()
    return useCallback(
      async function address(input) {
        const data = await fetch({ input })
        await revalidate()
        router.push("/address");
        return data
      },
      [fetch, revalidate]
    )
  },
}
