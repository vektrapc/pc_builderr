import { useCallback } from 'react';
import type { MutationHook } from '../../commerce/utils/types'
import { CommerceError } from '../../commerce/utils/errors'
import useCustomer, { UseCustomer } from "../../commerce/customer/use-customer"
import useRemoveAddress, { UseRemoveAddress } from "../../commerce/customer/use-address-remove"
import type { AddressRemoveHooks } from '../types/addressRemove'
import { addressRemoveMutation, getCustomerToken,throwUserErrors } from '../utils'
import { Mutation, MutationAddressremoveArgs } from '../schema'
import { useRouter } from 'next/router';
import { ToastContainer, toast } from 'react-toastify';
export default useRemoveAddress as UseRemoveAddress<typeof handler>

export const handler: MutationHook<AddressRemoveHooks> = {
  fetchOptions: {
    query: addressRemoveMutation,
  },
  async fetcher({ 
    input: id,
    options, 
    fetch ,
  }) {
    if(!id) {
      throw new CommerceError({
        message:
          'Address Id is required to recover account',
      })
    }
    const customerAccessToken = getCustomerToken()
    let customerAddress:any
    let customerUserErrors:any
    if (customerAccessToken) {
      const { customerAddressDelete } = await fetch<Mutation, MutationAddressremoveArgs>({
        ...options,
        variables: { 
          id: id,
          customerAccessToken: getCustomerToken() },
      }) 
      customerAddress = customerAddressDelete?.customerUserErrors
      customerUserErrors = customerAddressDelete?.customerUserErrors
       
      if(customerAddressDelete?.customerUserErrors.length == 0) {
        toast.success('Address Removed Successfully', {
          position: "bottom-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          });
      }
      return customerAddressDelete
    }
    throwUserErrors(customerUserErrors)
    return customerAddress
  },
  useHook: ({ fetch }) => () => {
    const router = useRouter()
    const { revalidate } = useCustomer()
    return useCallback(
      async function address(input) {
        const data = await fetch({ input })
        await revalidate()
        router.push("/address");
        return data
      },
      [fetch, revalidate]
    )
  },
}
