export * from '@commerce/product/compare-price'
export { default } from '@commerce/product/compare-price'
