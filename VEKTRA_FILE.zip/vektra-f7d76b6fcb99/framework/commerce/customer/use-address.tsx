import { useHook,useMutationHook } from '../utils/use-hook'
import { mutationFetcher } from '../utils/default-fetcher'
import type { MutationHook, HookFetcherFn } from '../utils/types'
import type { AddressHook } from '../types/address'
import type { Provider } from '..'
export type UseAddress<
  H extends MutationHook<AddressHook<any>> = MutationHook<AddressHook>
> = ReturnType<H['useHook']>

export const fetcher: HookFetcherFn<AddressHook> = mutationFetcher

const fn = (provider: Provider) => provider.customer?.useAddress!

const useAddress: UseAddress = (...args) => {
  const hook = useHook(fn)
  return useMutationHook({ fetcher, ...hook })(...args)
}

export default useAddress;