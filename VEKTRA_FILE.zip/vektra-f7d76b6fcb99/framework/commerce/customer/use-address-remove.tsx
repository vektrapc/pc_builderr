import { useHook,useMutationHook } from '../utils/use-hook'
import { mutationFetcher } from '../utils/default-fetcher'
import type { MutationHook, HookFetcherFn } from '../utils/types'
import type { AddressRemoveHooks } from '../types/addressRemove'
import type { Provider } from '..'
export type UseRemoveAddress<
  H extends MutationHook<AddressRemoveHooks<any>> = MutationHook<AddressRemoveHooks>
> = ReturnType<H['useHook']>

export const fetcher: HookFetcherFn<AddressRemoveHooks> = mutationFetcher

const fn = (provider: Provider) => provider.customer?.useRemoveAddress!

const useRemoveAddress: UseRemoveAddress = (...args) => {
  const hook = useHook(fn)
  return useMutationHook({ fetcher, ...hook })(...args)
}

export default useRemoveAddress;