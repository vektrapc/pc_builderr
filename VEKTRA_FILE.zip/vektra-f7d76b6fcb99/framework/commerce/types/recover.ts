export type RecoverBody = {
  // customerAccessToken: string
  email: string
}

export type RecoverTypes = {
  body: RecoverBody
}

export type RecoverHook<T extends RecoverTypes = RecoverTypes> = {
  data: null
  actionInput: RecoverBody
  fetcherInput: RecoverBody
  body: T['body']
}

export type RecoverSchema<T extends RecoverTypes = RecoverTypes> = {
  endpoint: {
    options: {}
    handlers: {
      recover: RecoverHook<T>
    }
  }
}

export type RecoverOperation = {
  data: { result?: string }
  variables: unknown
}
