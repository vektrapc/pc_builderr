export type AddressBody = {
    address1: string
    address2: string
    city: string
    company: string
    country: string
    firstName: string
    lastName: string
    phone: string
    province: string
    zip: string
  }
  
  export type AddressTypes = {
    body: AddressBody
  }
  
  export type AddressHook<T extends AddressTypes = AddressTypes> = {
    data: null
    actionInput: T['body']
    fetcherInput: T['body']
    body: T['body']
  }
  
  export type AddressSchema<T extends AddressTypes = AddressTypes> = {
    endpoint: {
      options: {}
      handlers: {
        address: AddressHook<T>
      }
    }
  }
  export type AddressOperation = {
    data: { result?: string }
    variables: unknown
  }
  