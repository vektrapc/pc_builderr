export type CheckoutSchema = {
  endpoint: {
    options: {}
    handlers: {
      checkout: {
        data: null
      }
    }
  }
}
