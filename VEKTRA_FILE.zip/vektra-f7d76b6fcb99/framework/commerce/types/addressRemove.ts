export type AddressRemoveBody = {
    id: string
  }
  
  export type AddressRemoveTypes = {
    body: AddressRemoveBody
  }
  
  export type AddressRemoveHooks<T extends AddressRemoveTypes = AddressRemoveTypes> = {
    data: null
    actionInput: T['body']
    fetcherInput: T['body']
    body: T['body']
  }
  
  export type AddressRemoveSchema<T extends AddressRemoveTypes = AddressRemoveTypes> = {
    endpoint: {
      options: {}
      handlers: {
        id: AddressRemoveHooks<T>
      }
    }
  }
  export type AddressRemoveOperation = {
    data: { result?: string }
    variables: unknown
  }
  