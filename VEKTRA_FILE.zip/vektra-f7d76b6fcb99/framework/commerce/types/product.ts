export type ProductImage = {
  url: string
  alt?: string
}

export type ProductPrice = {
  value: number
  currencyCode?: 'USD' | 'EUR' | 'ARS' | string
  retailPrice?: number
  salePrice?: number
  listPrice?: number
  extendedSalePrice?: number
  extendedListPrice?: number
}

export type ProductOption = {
  __typename?: 'MultipleChoiceOption'
  id: string
  displayName: string
  values: ProductOptionValues[]
}

export type ProductOptionValues = {
  label: string
  hexColors?: string[]
}

export type ProductVariant = {
  id: string | number
  price: number
  options: ProductOption[]
  availableForSale?: boolean
}

export type Product = {
  id: string
  name: string
  description: string
  availableForSale?: boolean
  descriptionHtml?: string
  sku?: string
  slug?: string
  path?: string
  images: ProductImage[]
  variants: ProductVariant[]
  compare_price: ProductPrice
  price: ProductPrice
  options: ProductOption[]
  vendor?:string
}

export type SearchProductsBody = {
  search?: string
  categoryId?: string | number
  brandId?: string | number
  sort?: string
  locale?: string
  first?: number
  last?: number
  before?: string
  after?: string
}

export type ProductTypes = {
  product: Product
  searchBody: SearchProductsBody
}
export type ProductEdge = {
  __typename?: 'ProductEdge'
  /** A cursor for use in pagination. */
  cursor: string
  /** The item at the end of ProductEdge. */
  node: Product
}
/** Information about pagination in a connection. */
export type PageInfo = {
  __typename?: 'PageInfo'
  /** When paginating forwards, are there more items? */
  hasNextPage: boolean
  /** When paginating backwards, are there more items? */
  hasPreviousPage: boolean
}

export type SearchProductsHook<T extends ProductTypes = ProductTypes> = {
  data: {
    products: T['product'][]
    collection?: {
      products?:{
        edges: Array<ProductEdge>
        pageInfo: PageInfo
        // edges?:{
        //   node?:{
        //     vendor: string
        //   }
        // }
      }
      seo?: {
        title?: string,
        description?: string
      }
      image?: {
        originalSrc?: string
      }
    }
    found: boolean
  }
  body: T['searchBody']
  input: T['searchBody']
  fetcherInput: T['searchBody']
}

export type ProductsSchema<T extends ProductTypes = ProductTypes> = {
  endpoint: {
    options: {}
    handlers: {
      getProducts: SearchProductsHook<T>
    }
  }
}

export type GetAllProductPathsOperation<
  T extends ProductTypes = ProductTypes
> = {
  data: { products: Pick<T['product'], 'path'>[] }
  variables: { first?: number }
}

export type GetAllProductsOperation<T extends ProductTypes = ProductTypes> = {
  data: { products: T['product'][] }
  variables: {
    relevance?: 'featured' | 'best_selling' | 'newest'
    ids?: string[]
    first?: number
  }
}

export type GetAllProductsFromCollectionsOperation<T extends ProductTypes = ProductTypes> = {
  data: { seo: any }
  variables: {
    search?: string
    categoryId?: string
    brandId?: number
    sort?: string
    locale?: string
    first?: number
    last?: number
    before?: string
    after?: string
  }
}

export type GetProductOperation<T extends ProductTypes = ProductTypes> = {
  data: { product?: T['product'] }
  variables: { path: string; slug?: never } | { path?: never; slug: string }
}
