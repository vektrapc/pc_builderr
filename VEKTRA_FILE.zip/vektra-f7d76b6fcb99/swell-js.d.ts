declare module 'swell-js'
