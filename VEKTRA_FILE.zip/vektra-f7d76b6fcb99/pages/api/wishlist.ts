import wishlistApi from '@framework/api/endpoints/wishlist'
import commerce from '@lib/api/commerce'

export default wishlistApi(commerce)
