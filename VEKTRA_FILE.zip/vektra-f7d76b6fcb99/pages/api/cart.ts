import cartApi from '../../framework/shopify/api/endpoints/cart';
import commerce from '@lib/api/commerce';

export default cartApi(commerce)
