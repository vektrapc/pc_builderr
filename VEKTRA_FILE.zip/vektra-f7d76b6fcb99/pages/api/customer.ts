import customerApi from '../../framework/shopify/api/endpoints/customer'
import commerce from '@lib/api/commerce'

export default customerApi(commerce)
