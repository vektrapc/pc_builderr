import checkoutApi from '../../framework/shopify/api/endpoints/checkout'
import commerce from '@lib/api/commerce'

export default checkoutApi(commerce)
