import logoutApi from '@framework/api/endpoints/logout'
import commerce from '@lib/api/commerce'

export default logoutApi(commerce)
