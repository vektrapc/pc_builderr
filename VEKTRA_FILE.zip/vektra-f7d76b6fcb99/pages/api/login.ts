import loginApi from '../../framework/shopify/api/endpoints/login'
import commerce from '@lib/api/commerce'

export default loginApi(commerce)
